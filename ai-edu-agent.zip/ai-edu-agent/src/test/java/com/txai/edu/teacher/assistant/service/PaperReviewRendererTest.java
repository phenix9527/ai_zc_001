package com.txai.edu.teacher.assistant.service;

import com.txai.edu.teacher.assistant.dto.ErrorWordPaperDTO;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

class PaperReviewRendererTest {

    private final PaperReviewRenderer renderer = new PaperReviewRenderer();

    @Test
    void shouldRenderAnswerAnalysisColumnInErrorPaperPreview() {
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setQuestionNo(1);
        paper.setWrongWord("obvious");
        paper.setQuestionContent("The answer is ____.");
        paper.setDifficultyStar(2);
        paper.setAnswerAnalysis("固定搭配 be obvious to sb.");

        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        String preview = renderer.renderErrorPaperPreview(dto);

        assertTrue(preview.contains("| 序号 | 错词 | 题目内容 | 难度 | 答案解析 |"));
        assertTrue(preview.contains("固定搭配 be obvious to sb."));
    }

    @Test
    void libraryPreviewUsesNewQuestionHeading() {
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setQuestionNo(11);
        paper.setWrongWord("where");
        paper.setQuestionContent("____ you go.");
        paper.setDifficultyStar(3);
        paper.setAnswerAnalysis("-");
        paper.setPaperId("lib-paper-001");

        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        String preview = renderer.renderLibraryPaperPreview(dto);

        assertTrue(preview.contains("### 新题组卷预览"));
        assertTrue(preview.contains("| 序号 | 错词 | 题目内容 | 难度 | 答案解析 |"));
        assertTrue(preview.contains("where"));
        assertTrue(preview.contains("**试卷ID**"));
        assertTrue(preview.contains("`lib-paper-001`"));
    }

    @Test
    void replacePreviewUsesDedicatedHeading() {
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setQuestionNo(1);
        paper.setWrongWord("run");
        paper.setQuestionContent("They ______ every morning.");
        paper.setDifficultyStar(2);
        paper.setAnswerAnalysis("run");
        paper.setPaperId("rep-paper-xyz");
        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        String preview = renderer.renderReplaceQuestionPreview(dto);

        assertTrue(preview.contains("### 同词换题预览"));
        assertTrue(preview.contains("run"));
        assertTrue(preview.contains("`rep-paper-xyz`"));
    }
}
