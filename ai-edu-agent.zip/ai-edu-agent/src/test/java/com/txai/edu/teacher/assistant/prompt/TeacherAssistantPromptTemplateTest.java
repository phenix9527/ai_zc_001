package com.txai.edu.teacher.assistant.prompt;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertFalse;

class TeacherAssistantPromptTemplateTest {

    @Test
    void systemPromptShouldNotContainUnboundTemplateVariables() throws IOException {
        var resource = getClass().getClassLoader().getResourceAsStream("prompts/teacher-assistant-system.txt");
        if (resource == null) {
            throw new IllegalStateException("prompts/teacher-assistant-system.txt not found");
        }
        String content = new String(resource.readAllBytes(), StandardCharsets.UTF_8);
        assertFalse(content.contains("{{"), "system prompt contains unbound template variable start token");
        assertFalse(content.contains("}}"), "system prompt contains unbound template variable end token");
    }
}
