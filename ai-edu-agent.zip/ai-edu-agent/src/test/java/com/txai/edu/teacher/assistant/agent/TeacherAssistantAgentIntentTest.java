package com.txai.edu.teacher.assistant.agent;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TeacherAssistantAgentIntentTest {

    @Test
    void wantsQuestionLibraryPaperIntent_recognizesShortCue() {
        assertTrue(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("新题"));
        assertTrue(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("  新题  "));
        assertTrue(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("来10道新题"));
    }

    @Test
    void wantsQuestionLibraryPaperIntent_recognizesLongPhrases() {
        assertTrue(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("新题组卷"));
        assertTrue(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("题库组卷"));
    }

    @Test
    void wantsQuestionLibraryPaperIntent_excludesNewQuestionTypePhrase() {
        assertFalse(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("新题型怎么讲"));
    }

    @Test
    void wantsQuestionLibraryPaperIntent_blankOrNull() {
        assertFalse(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent(null));
        assertFalse(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent(""));
        assertFalse(TeacherAssistantAgent.wantsQuestionLibraryPaperIntent("   "));
    }
}
