package com.txai.edu.teacher.assistant.service;

import com.txai.edu.teacher.assistant.dto.ErrorWordPaperDTO;
import com.txai.edu.teacher.assistant.entity.po.PaperQuestionPreviewPO;
import com.txai.edu.teacher.assistant.mapper.PaperQuestionPreviewMapper;
import com.txai.edu.teacher.assistant.mcp.PaperPracticeResultMcpAdapter;
import com.txai.edu.teacher.assistant.session.TeacherContextHolder;
import com.txai.edu.teacher.assistant.session.TeacherSessionService;
import com.txai.edu.teacher.assistant.tool.Result;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PaperReviewServiceTest {

    @Mock
    private PaperPracticeResultMcpAdapter paperPracticeResultMcpAdapter;

    @Mock
    private PaperQuestionPreviewMapper paperQuestionPreviewMapper;

    @Mock
    private TeacherSessionService teacherSessionService;

    @InjectMocks
    private PaperReviewService paperReviewService;

    @AfterEach
    void clearContext() {
        TeacherContextHolder.clear();
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldPersistErrorQuestionPreviewWithTypeOne() {
        TeacherContextHolder.setTeacherId("t-1001");
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setPaperId("p-2001");
        paper.setQuestionNo(1);
        paper.setQuestionId("q-3001");
        paper.setWrongWord("obvious");
        paper.setQuestionContent("The answer is ____.");
        paper.setAnswerAnalysis("analysis");
        paper.setDifficultyStar(2);
        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        when(paperPracticeResultMcpAdapter.genPaperReviewErrorQuestion(
                anyList(), anyList(), anyList(), nullable(String.class), nullable(String.class), anyInt()))
                .thenReturn(Result.ok(dto));
        when(paperQuestionPreviewMapper.batchInsert(anyList())).thenReturn(1);

        paperReviewService.genPaperReviewErrorQuestion("chat-err-1", List.of("obvious"), List.of("C1"), List.of("P1"), null, null, 10);

        ArgumentCaptor<List<PaperQuestionPreviewPO>> captor = ArgumentCaptor.forClass(List.class);
        verify(paperQuestionPreviewMapper).batchInsert(captor.capture());
        PaperQuestionPreviewPO saved = captor.getValue().getFirst();
        assertEquals("t-1001", saved.getTeacherId());
        assertEquals("p-2001", saved.getPaperId());
        assertEquals(1, saved.getGenPaperType());
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldPersistLibraryPreviewWithTypeTwo() {
        TeacherContextHolder.setTeacherId("t-1002");
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setPaperId("lib-p-1");
        paper.setQuestionNo(1);
        paper.setQuestionId("q-lib-1");
        paper.setWrongWord("where");
        paper.setQuestionContent("____ you go.");
        paper.setAnswerAnalysis("-");
        paper.setDifficultyStar(3);
        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        when(paperPracticeResultMcpAdapter.genPaperReviewQuestionLibrary(
                anyString(), anyString(), anyList(), anyList(), anyList(), anyInt(), any()))
                .thenReturn(Result.ok(dto));
        when(paperQuestionPreviewMapper.batchInsert(anyList())).thenReturn(1);

        paperReviewService.genPaperReviewQuestionLibrary(
                "chat-lib-1", List.of("w1"), "high", "高中", List.of("语境填词"), List.of("88"), 10);

        ArgumentCaptor<List<PaperQuestionPreviewPO>> captor = ArgumentCaptor.forClass(List.class);
        verify(paperQuestionPreviewMapper).batchInsert(captor.capture());
        PaperQuestionPreviewPO saved = captor.getValue().getFirst();
        assertEquals("t-1002", saved.getTeacherId());
        assertEquals(2, saved.getGenPaperType());
        assertEquals("q-lib-1", saved.getQuestionId());
        assertEquals("where", saved.getWrongWord());
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldPersistLibraryPreviewWhenMcpOmitsPaperId_uses32CharPaperId() {
        TeacherContextHolder.setTeacherId("t-1003");
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setPaperId(null);
        paper.setQuestionNo(null);
        paper.setQuestionId("q1");
        paper.setWrongWord("w");
        paper.setQuestionContent("c");
        paper.setAnswerAnalysis("-");
        paper.setDifficultyStar(1);
        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        when(paperPracticeResultMcpAdapter.genPaperReviewQuestionLibrary(
                anyString(), anyString(), anyList(), anyList(), anyList(), anyInt(), any()))
                .thenReturn(Result.ok(dto));
        when(paperQuestionPreviewMapper.batchInsert(anyList())).thenReturn(1);

        paperReviewService.genPaperReviewQuestionLibrary(
                "chat-lib-2", List.of("w1"), "high", "高中", List.of(), List.of(), 10);

        ArgumentCaptor<List<PaperQuestionPreviewPO>> captor = ArgumentCaptor.forClass(List.class);
        verify(paperQuestionPreviewMapper).batchInsert(captor.capture());
        String paperId = captor.getValue().getFirst().getPaperId();
        assertEquals(32, paperId.length());
        assertTrue(paperId.chars().allMatch(c -> (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')));
        assertEquals(1, captor.getValue().getFirst().getQuestionNo());
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldPersistLibraryWhenThreadLocalEmpty_resolvesTeacherIdViaChatId() {
        TeacherContextHolder.clear();
        when(teacherSessionService.requireTeacherId("cid-only")).thenReturn("teacher-from-session");
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setPaperId("lib-p-2");
        paper.setQuestionNo(1);
        paper.setQuestionId("q1");
        paper.setWrongWord("w");
        paper.setQuestionContent("c");
        paper.setAnswerAnalysis("-");
        paper.setDifficultyStar(1);
        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        when(paperPracticeResultMcpAdapter.genPaperReviewQuestionLibrary(
                anyString(), anyString(), anyList(), anyList(), anyList(), anyInt(), any()))
                .thenReturn(Result.ok(dto));
        when(paperQuestionPreviewMapper.batchInsert(anyList())).thenReturn(1);

        paperReviewService.genPaperReviewQuestionLibrary(
                "cid-only", List.of("w1"), "high", "高中", List.of(), List.of(), 10);

        verify(teacherSessionService).requireTeacherId("cid-only");
        ArgumentCaptor<List<PaperQuestionPreviewPO>> captor = ArgumentCaptor.forClass(List.class);
        verify(paperQuestionPreviewMapper).batchInsert(captor.capture());
        assertEquals("teacher-from-session", captor.getValue().getFirst().getTeacherId());
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldReplaceSingleQuestionAndPersist() {
        TeacherContextHolder.setTeacherId("t-rep-1");
        ErrorWordPaperDTO.ErrorWordPaper paper = new ErrorWordPaperDTO.ErrorWordPaper();
        paper.setPaperId("paper-x");
        paper.setQuestionNo(1);
        paper.setQuestionId("Q-REP-MOCK-9001");
        paper.setWrongWord("obvious");
        paper.setQuestionContent("（换题 mock）The solution is ______ to anyone.");
        paper.setAnswerAnalysis("obvious");
        paper.setDifficultyStar(2);
        ErrorWordPaperDTO dto = new ErrorWordPaperDTO();
        dto.setErrorWordPapers(List.of(paper));

        when(paperPracticeResultMcpAdapter.replaceSingleQuestion(anyString(), anyInt(), anyString()))
                .thenReturn(Result.ok(dto));
        when(paperQuestionPreviewMapper.findLatestActivePaperId(anyString(), anyInt(), anyString()))
                .thenReturn("paper-x");
        when(paperQuestionPreviewMapper.batchInsert(anyList())).thenReturn(1);
        when(paperQuestionPreviewMapper.logicDeleteReplacedPreviewRow(anyString(), anyString(), anyInt(), anyString()))
                .thenReturn(1);

        paperReviewService.replaceSingleQuestion("chat-rep", "zhoucong", 11, "obvious");

        verify(paperPracticeResultMcpAdapter).replaceSingleQuestion(eq("paper-x"), eq(11), eq("obvious"));
        var inOrder = inOrder(paperQuestionPreviewMapper);
        inOrder.verify(paperQuestionPreviewMapper).logicDeleteReplacedPreviewRow(
                eq("t-rep-1"), eq("paper-x"), eq(11), eq("obvious"));
        ArgumentCaptor<List<PaperQuestionPreviewPO>> captor = ArgumentCaptor.forClass(List.class);
        inOrder.verify(paperQuestionPreviewMapper).batchInsert(captor.capture());
        assertEquals("t-rep-1", captor.getValue().getFirst().getTeacherId());
        assertEquals(3, captor.getValue().getFirst().getGenPaperType());
        assertEquals("Q-REP-MOCK-9001", captor.getValue().getFirst().getQuestionId());
        verify(paperQuestionPreviewMapper).findLatestActivePaperId(eq("t-rep-1"), eq(11), eq("obvious"));
    }
}
