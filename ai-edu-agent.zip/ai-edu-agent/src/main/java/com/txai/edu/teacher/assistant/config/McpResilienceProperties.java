package com.txai.edu.teacher.assistant.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * MCP 调用可靠性参数。
 */
@Data
@ConfigurationProperties(prefix = "resilience.mcp")
public class McpResilienceProperties {
    private int timeoutMs = 2000;
    private int maxRetries = 2;
    private int retryFirstDelayMs = 80;
    private double retryMultiplier = 2.0;
    private int retryMaxDelayMs = 2000;
    private int circuitBreakerFailureThresholdCount = 5;
    private int circuitBreakerOpenSeconds = 30;
}
