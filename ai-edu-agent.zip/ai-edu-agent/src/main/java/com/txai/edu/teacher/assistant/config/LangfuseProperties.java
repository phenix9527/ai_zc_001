package com.txai.edu.teacher.assistant.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Langfuse 观测（ingestion API）。需显式 {@code langfuse.enabled=true} 且配置密钥后才会注册客户端与监听器。
 * @author zhoucong
 */
@Data
@ConfigurationProperties(prefix = "langfuse")
public class LangfuseProperties {

    /**
     * 关闭时不注册 {@link com.langfuse.client.LangfuseClient} 与 Chat 监听器，避免本地缺省密钥时报错。
     */
    private boolean enabled = false;

    /**
     * Langfuse 服务根地址，勿带末尾 {@code /}（会在客户端创建时归一化）。
     */
    private String host = "http://127.0.0.1:3000";

    private String publicKey = "";
    private String secretKey = "";
}
