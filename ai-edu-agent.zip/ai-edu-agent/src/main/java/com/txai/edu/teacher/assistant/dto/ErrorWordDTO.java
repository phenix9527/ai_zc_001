package com.txai.edu.teacher.assistant.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zhoucong
 */
@Data
public class ErrorWordDTO {
    private List<ErrorWord> errorWords;

    @Data
    public static class ErrorWord {
        private String errorRate;
        private String wordId;
        private String wordContent;
    }
}
