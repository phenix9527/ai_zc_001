package com.txai.edu.teacher.assistant.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.txai.edu.teacher.assistant.entity.po.PaperQuestionPreviewPO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author zhoucong
 */
public interface PaperQuestionPreviewMapper extends BaseMapper<PaperQuestionPreviewPO> {

    int batchInsert(@Param("list") List<PaperQuestionPreviewPO> list);

    /**
     * 同词换题：将指定教师、试卷、题目序号（与预览表「序号」一致）、错词对应的未删除预览行标记为已删除。
     *
     * @return 受影响行数，期望为 1
     */
    int logicDeleteReplacedPreviewRow(@Param("teacherId") String teacherId,
                                      @Param("paperId") String paperId,
                                      @Param("questionNo") Integer questionNo,
                                      @Param("wrongWord") String wrongWord);

    /**
     * 按教师 + 预览行维度查找当前未删除的预览卷 ID（同序号、错词可能对应多卷时取 id 最大的一条，即最近落库）。
     */
    String findLatestActivePaperId(@Param("teacherId") String teacherId,
                                  @Param("questionNo") Integer questionNo,
                                  @Param("wrongWord") String wrongWord);
}
