package com.txai.edu.teacher.assistant.config;

import com.langfuse.client.LangfuseClient;
import com.langfuse.client.core.LangfuseClientApiException;
import com.langfuse.client.resources.commons.types.Usage;
import com.langfuse.client.resources.ingestion.requests.IngestionRequest;
import com.langfuse.client.resources.ingestion.types.CreateGenerationBody;
import com.langfuse.client.resources.ingestion.types.CreateGenerationEvent;
import com.langfuse.client.resources.ingestion.types.IngestionEvent;
import com.langfuse.client.resources.ingestion.types.IngestionUsage;
import com.langfuse.client.resources.ingestion.types.TraceBody;
import com.langfuse.client.resources.ingestion.types.TraceEvent;
import com.langfuse.client.resources.ingestion.types.UpdateGenerationBody;
import com.langfuse.client.resources.ingestion.types.UpdateGenerationEvent;
import com.txai.edu.teacher.assistant.session.TeacherContextHolder;
import dev.langchain4j.agent.tool.ToolExecutionRequest;
import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.SystemMessage;
import dev.langchain4j.data.message.TextContent;
import dev.langchain4j.data.message.ToolExecutionResultMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.model.chat.listener.ChatModelErrorContext;
import dev.langchain4j.model.chat.listener.ChatModelListener;
import dev.langchain4j.model.chat.listener.ChatModelRequestContext;
import dev.langchain4j.model.chat.listener.ChatModelResponseContext;
import dev.langchain4j.model.output.TokenUsage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Langfuse Java 0.2.x 为 Fern 生成的 {@link LangfuseClient}，通过 ingestion 批量上报 trace / generation。
 * 每次模型请求均发送 {@code trace-create} + {@code generation-create}（同一 traceId 由 Langfuse 合并），避免依赖 Redis 去重时误判导致只发 generation、Trace 缺失而上报失败。
 * LangChain4j 1.12.x 监听器：{@link ChatModelRequestContext#chatRequest()}、
 * {@link ChatModelResponseContext#chatResponse()}（旧版 {@code request()}/{@code response()} 已更名）。
 */
@Configuration
@ConditionalOnProperty(prefix = "langfuse", name = "enabled", havingValue = "true")
public class LangfuseConfig {

    private static final Logger log = LoggerFactory.getLogger(LangfuseConfig.class);

    @Bean
    public LangfuseClient langfuseClient(LangfuseProperties properties) {
        String base = properties.getHost() == null ? "" : properties.getHost().trim();
        while (base.endsWith("/")) {
            base = base.substring(0, base.length() - 1);
        }
        if (base.isEmpty()) {
            base = "http://127.0.0.1:3000";
        }
        return LangfuseClient.builder()
                .url(base)
                .credentials(
                        nullToEmpty(properties.getPublicKey()).trim(),
                        nullToEmpty(properties.getSecretKey()).trim())
                .build();
    }

    @Bean
    public ChatModelListener langfuseChatModelListener(LangfuseClient langfuseClient) {
        return new LangfuseIngestionListener(langfuseClient);
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    /**
     * Langfuse 使用 Jackson 序列化 ingestion 请求；LangChain4j 的 {@link ChatMessage} 实现类无 Bean 属性，不能直接作为 JSON 字段。
     */
    private static List<Map<String, Object>> messagesToLangfuseInput(Object rawMessages) {
        if (!(rawMessages instanceof List<?> list) || list.isEmpty()) {
            return List.of();
        }
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object item : list) {
            if (item instanceof ChatMessage m) {
                out.add(chatMessageToMap(m));
            }
        }
        return out;
    }

    private static Map<String, Object> chatMessageToMap(ChatMessage m) {
        return switch (m.type()) {
            case SYSTEM -> Map.of(
                    "role", "system",
                    "content", ((SystemMessage) m).text());
            case USER -> userMessageToMap((UserMessage) m);
            case AI -> aiMessageToMap((AiMessage) m);
            case TOOL_EXECUTION_RESULT -> toolResultToMap((ToolExecutionResultMessage) m);
            case CUSTOM -> Map.of("role", "custom", "content", String.valueOf(m));
        };
    }

    private static Map<String, Object> userMessageToMap(UserMessage um) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("role", "user");
        if (um.name() != null && !um.name().isBlank()) {
            map.put("name", um.name());
        }
        if (um.hasSingleText()) {
            map.put("content", um.singleText());
        } else {
            List<Map<String, String>> parts = new ArrayList<>();
            for (Object c : um.contents()) {
                if (c instanceof TextContent tc) {
                    parts.add(Map.of("type", "text", "text", tc.text()));
                } else {
                    parts.add(Map.of("type", c.getClass().getSimpleName()));
                }
            }
            map.put("content", parts);
        }
        return map;
    }

    private static Map<String, Object> aiMessageToMap(AiMessage am) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("role", "assistant");
        if (am.text() != null) {
            map.put("content", am.text());
        }
        if (am.hasToolExecutionRequests()) {
            List<Map<String, String>> calls = new ArrayList<>();
            for (Object r : am.toolExecutionRequests()) {
                if (r instanceof ToolExecutionRequest ter) {
                    Map<String, String> one = new LinkedHashMap<>();
                    one.put("id", ter.id());
                    one.put("name", ter.name());
                    if (ter.arguments() != null) {
                        one.put("arguments", ter.arguments());
                    }
                    calls.add(one);
                }
            }
            if (!calls.isEmpty()) {
                map.put("tool_calls", calls);
            }
        }
        return map;
    }

    private static Map<String, Object> toolResultToMap(ToolExecutionResultMessage msg) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("role", "tool");
        if (msg.id() != null) {
            map.put("id", msg.id());
        }
        if (msg.toolName() != null) {
            map.put("name", msg.toolName());
        }
        map.put("content", msg.text());
        return map;
    }

    static final class LangfuseIngestionListener implements ChatModelListener {

        private final LangfuseClient client;

        LangfuseIngestionListener(LangfuseClient client) {
            this.client = client;
        }

        @Override
        public void onRequest(ChatModelRequestContext context) {
            String traceId = LangfuseTraceContext.traceId();
            if (traceId == null || traceId.isBlank()) {
                traceId = UUID.randomUUID().toString();
            }
            String generationId = UUID.randomUUID().toString();
            context.attributes().put("langfuse_trace_id", traceId);
            context.attributes().put("langfuse_generation_id", generationId);

            String now = OffsetDateTime.now(ZoneOffset.UTC).toString();
            String userId = TeacherContextHolder.getTeacherId();
            if (userId == null || userId.isBlank()) {
                userId = "anonymous";
            }

            String sessionLabel = LangfuseTraceContext.sessionLabel();
            TraceBody.Builder traceBody = TraceBody.builder()
                    .id(traceId)
                    .name("Teacher-Assistant-Chat")
                    .userId(userId);
            if (sessionLabel != null && !sessionLabel.isBlank()) {
                traceBody.sessionId(sessionLabel);
            }

            TraceEvent traceEvent = TraceEvent.builder()
                    .id(UUID.randomUUID().toString())
                    .timestamp(now)
                    .body(traceBody.build())
                    .build();

            Object inputPayload = messagesToLangfuseInput(context.chatRequest().messages());

            CreateGenerationBody genBody = CreateGenerationBody.builder()
                    .id(generationId)
                    .traceId(traceId)
                    .name("chat-turn")
                    .model(context.chatRequest().modelName())
                    .input(inputPayload)
                    .build();

            CreateGenerationEvent genEvent = CreateGenerationEvent.builder()
                    .id(UUID.randomUUID().toString())
                    .timestamp(now)
                    .body(genBody)
                    .build();

            try {
                client.ingestion().batch(IngestionRequest.builder()
                        .addBatch(IngestionEvent.traceCreate(traceEvent))
                        .addBatch(IngestionEvent.generationCreate(genEvent))
                        .build());
            } catch (LangfuseClientApiException e) {
                log.warn("Langfuse ingestion (trace+generation create) failed: status={} body={}",
                        e.statusCode(), e.body(), e);
            } catch (RuntimeException e) {
                log.warn("Langfuse ingestion (trace+generation create) failed", e);
            }
        }

        @Override
        public void onResponse(ChatModelResponseContext context) {
            String traceId = (String) context.attributes().get("langfuse_trace_id");
            String generationId = (String) context.attributes().get("langfuse_generation_id");
            if (traceId == null || generationId == null) {
                return;
            }

            String output = "";
            if (context.chatResponse().aiMessage() != null && context.chatResponse().aiMessage().text() != null) {
                output = context.chatResponse().aiMessage().text();
            }

            IngestionUsage usagePayload = buildUsage(context.chatResponse().tokenUsage());

            UpdateGenerationBody updateBody = UpdateGenerationBody.builder()
                    .id(generationId)
                    .traceId(traceId)
                    .output(output)
                    .usage(usagePayload)
                    .build();

            UpdateGenerationEvent updateEvent = UpdateGenerationEvent.builder()
                    .id(UUID.randomUUID().toString())
                    .timestamp(OffsetDateTime.now(ZoneOffset.UTC).toString())
                    .body(updateBody)
                    .build();

            try {
                client.ingestion().batch(IngestionRequest.builder()
                        .addBatch(IngestionEvent.generationUpdate(updateEvent))
                        .build());
            } catch (LangfuseClientApiException e) {
                log.warn("Langfuse ingestion (generation update) failed: status={} body={}",
                        e.statusCode(), e.body(), e);
            } catch (RuntimeException e) {
                log.warn("Langfuse ingestion (generation update) failed", e);
            }
        }

        @Override
        public void onError(ChatModelErrorContext context) {
            String traceId = (String) context.attributes().get("langfuse_trace_id");
            if (traceId != null) {
                log.warn("Chat model error (langfuse traceId={}): {}", traceId, context.error().toString());
            }
        }

        private static IngestionUsage buildUsage(TokenUsage tokenUsage) {
            if (tokenUsage == null) {
                return null;
            }
            int input = tokenUsage.inputTokenCount() == null ? 0 : tokenUsage.inputTokenCount();
            int output = tokenUsage.outputTokenCount() == null ? 0 : tokenUsage.outputTokenCount();
            int total = tokenUsage.totalTokenCount() == null ? input + output : tokenUsage.totalTokenCount();
            Usage usage = Usage.builder()
                    .input(input)
                    .output(output)
                    .total(total)
                    .build();
            return IngestionUsage.of(usage);
        }
    }
}
