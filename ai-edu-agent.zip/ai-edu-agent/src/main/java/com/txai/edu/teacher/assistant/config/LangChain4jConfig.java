package com.txai.edu.teacher.assistant.config;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.chat.StreamingChatModel;
import dev.langchain4j.model.chat.listener.ChatModelListener;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.model.openai.OpenAiStreamingChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.List;

/**
 * 同步 {@link ChatModel} 与流式 {@link StreamingChatModel} 均挂载相同的 {@link ChatModelListener}，
 * 以便 Langfuse 等在流式调用中也能收到 onRequest/onResponse。
 */
@Configuration
public class LangChain4jConfig {

    @Bean
    ChatModel chatModel(AiModelProperties props, List<ChatModelListener> listeners) {
        var builder = OpenAiChatModel.builder()
                .baseUrl(props.getBaseUrl())
                .apiKey(props.getApiKey())
                .modelName(props.getModelName())
                .temperature(props.getTemperature())
                .topP(props.getTopP())
                .timeout(Duration.ofMillis(Math.max(1000, props.getTimeoutMs())));
        if (!listeners.isEmpty()) {
            builder.listeners(listeners);
        }
        return builder.build();
    }

    @Bean
    StreamingChatModel streamingChatModel(AiModelProperties props, List<ChatModelListener> listeners) {
        var builder = OpenAiStreamingChatModel.builder()
                .baseUrl(props.getBaseUrl())
                .apiKey(props.getApiKey())
                .modelName(props.getModelName())
                .temperature(props.getTemperature())
                .topP(props.getTopP())
                .timeout(Duration.ofMillis(Math.max(1000, props.getTimeoutMs())));
        if (!listeners.isEmpty()) {
            builder.listeners(listeners);
        }
        return builder.build();
    }
}
