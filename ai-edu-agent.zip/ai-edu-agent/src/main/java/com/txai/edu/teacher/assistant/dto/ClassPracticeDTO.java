package com.txai.edu.teacher.assistant.dto;

import lombok.Data;

import java.util.List;

/**
 * @author zhoucong
 */
@Data
public class ClassPracticeDTO {

    private List<ErrorWordPracticesDTO> errorWordPractices;

    @Data
    public static class ErrorWordPracticesDTO {
        private String classId;
        private String className;
        private String practiceId;
        private String practiceName;
        private Long startTime;
        private Long endTime;
    }
}
