package com.txai.edu.teacher.assistant.session;

/**
 * 请求级教师上下文。
 * @author zhoucong
 */
public final class TeacherContextHolder {

    private static final ThreadLocal<String> TEACHER_ID = new ThreadLocal<>();

    private TeacherContextHolder() {
    }

    public static void setTeacherId(String teacherId) {
        TEACHER_ID.set(teacherId);
    }

    public static String getTeacherId() {
        return TEACHER_ID.get();
    }

    public static void clear() {
        TEACHER_ID.remove();
    }
}
