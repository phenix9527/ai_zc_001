package com.txai.edu.teacher.assistant.mcp;

import com.alibaba.fastjson2.JSON;
import com.txai.edu.teacher.assistant.dto.ClassPracticeDTO;
import com.txai.edu.teacher.assistant.dto.ErrorWordPaperDTO;
import com.txai.edu.teacher.assistant.dto.ErrorWordDTO;
import com.txai.edu.teacher.assistant.dto.TeacherClassDTO;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.tool.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhoucong
 */
@Component
@RequiredArgsConstructor
public class PaperPracticeResultMcpAdapter {

    private final TeacherMcpAdapter teacherMcpAdapter;

    private final PaperPracticeResultMcpClient paperPracticeResultMcpClient;

    public Result<ClassPracticeDTO> listPracticeByTeacherAndClass(String teacherId, List<String> classIds, Long startTime, Long endTime) {
        // 数据合法性校验
        if (CollectionUtils.isEmpty(classIds)) {
            return Result.fail(EduTeacherEnum.CLASS_ID_ISNULL);
        }
        // 教师和班级的关系验证
        Result<TeacherClassDTO> teacherRelatedClasses = teacherMcpAdapter.getTeacherRelatedClasses(teacherId);
        if (!teacherRelatedClasses.success()) {
            return Result.fail(EduTeacherEnum.GET_TEACHER_CLASS_INFO_FAIL);
        }
        List<String> teacherClassIds = teacherRelatedClasses.data().getClassInfos().stream().map(TeacherClassDTO.ClassInfoDTO::getClassId).toList();
        if (!teacherClassIds.containsAll(classIds)) {
            return Result.fail(EduTeacherEnum.TEACHER_CLASS_RELATION_INVALID);
        }

        // 兜底处理，近两个月的数据
        if (startTime == null || endTime == null) {
            endTime = System.currentTimeMillis();
            startTime = endTime - 60 * 60 * 24 * 30 * 2 * 1000;
        }

        Result<String> raw = paperPracticeResultMcpClient.callExternalSystem("paper", "/class/practice/error", teacherId, classIds, startTime, endTime);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }
        try {
            ClassPracticeDTO classPracticeDTO = JSON.parseObject(raw.data(), ClassPracticeDTO.class);
            if (classPracticeDTO == null) {
                return Result.fail(EduTeacherEnum.GET_CLASS_ERROR_PRACTICE_INVALID);
            }
            return Result.ok(classPracticeDTO);
        } catch (Exception e) {
            return Result.fail(EduTeacherEnum.GET_CLASS_ERROR_PRACTICE_INVALID);
        }
    }

    public Result<List<ErrorWordDTO>> listWrongWordSortedByErrorRate(List<String> practiceIds, String errorRate) {
        if (CollectionUtils.isEmpty(practiceIds)) {
            return Result.fail(EduTeacherEnum.GET_PRACTICE_ERROR_WORD_INVALID);
        }

        Result<String> raw = paperPracticeResultMcpClient.callExternalSystem("paper", "/practice/error/word", practiceIds, errorRate);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }

        try {
            List<ErrorWordDTO> errorWordDTOS = JSON.parseArray(raw.data(), ErrorWordDTO.class);
            if (CollectionUtils.isEmpty(errorWordDTOS)) {
                return Result.fail(EduTeacherEnum.GET_PRACTICE_ERROR_WORD_INVALID);
            }
            return Result.ok(errorWordDTOS);
        } catch (Exception e) {
            return Result.fail(EduTeacherEnum.GET_PRACTICE_ERROR_WORD_INVALID);
        }
    }

    public Result<ErrorWordPaperDTO> genPaperReviewQuestionLibrary(String stageId,
                                                        String stageName,
                                                        List<String> wordIds,
                                                        List<String> questionTypes,
                                                        List<String> wordErrorRates,
                                                        Integer totalCount,
                                                        int[] perWord) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("stageId", stageId);
        payload.put("stageName", stageName);
        payload.put("wordIds", wordIds == null ? List.of() : wordIds);
        payload.put("questionTypes", questionTypes == null ? List.of() : questionTypes);
        payload.put("wordErrorRates", wordErrorRates == null ? List.of() : wordErrorRates);
        payload.put("totalCount", totalCount);
        payload.put("perWord", perWord == null ? List.of() : java.util.Arrays.stream(perWord).boxed().toList());
        Result<String> raw = paperPracticeResultMcpClient.callExternalSystem("paper", "/paper/review/library", payload);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }
        return parseErrorWordPaper(raw.data(), EduTeacherEnum.MCP_UNKNOWN.getCode(), "题库组卷MCP返回无效");
    }

    public Result<ErrorWordPaperDTO> genPaperReviewErrorQuestion(List<String> words,
                                                                 List<String> classIds,
                                                                 List<String> practiceIds,
                                                                 String startTime,
                                                                 String endTime,
                                                                 Integer totalCount) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("words", words == null ? List.of() : words);
        payload.put("classIds", classIds == null ? List.of() : classIds);
        payload.put("practiceIds", practiceIds == null ? List.of() : practiceIds);
        payload.put("startTime", startTime);
        payload.put("endTime", endTime);
        payload.put("totalCount", totalCount);
        Result<String> raw = paperPracticeResultMcpClient.callExternalSystem("paper", "/paper/review/error", payload);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }
        return parseErrorWordPaper(raw.data(), EduTeacherEnum.MCP_UNKNOWN.getCode(), "原题组卷MCP返回无效");
    }

    public Result<ErrorWordPaperDTO> replaceSingleQuestion(String paperId, Integer questionNo, String wrongWord) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("paperId", paperId);
        payload.put("questionNo", questionNo);
        payload.put("wrongWord", wrongWord);
        Result<String> raw = paperPracticeResultMcpClient.callExternalSystem("paper", "/paper/review/replace", payload);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }
        return parseErrorWordPaper(raw.data(), EduTeacherEnum.MCP_UNKNOWN.getCode(), "同词换题MCP返回无效");
    }

    private static Result<ErrorWordPaperDTO> parseErrorWordPaper(String data, Integer code, String message) {
        try {
            ErrorWordPaperDTO dto = JSON.parseObject(data, ErrorWordPaperDTO.class);
            if (dto == null || CollectionUtils.isEmpty(dto.getErrorWordPapers())) {
                return Result.fail(code, message);
            }
            return Result.ok(dto);
        } catch (Exception e) {
            return Result.fail(code, message);
        }
    }
}
