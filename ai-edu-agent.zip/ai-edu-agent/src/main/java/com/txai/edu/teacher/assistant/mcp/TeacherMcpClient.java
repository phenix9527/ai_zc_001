package com.txai.edu.teacher.assistant.mcp;

import com.txai.edu.teacher.assistant.config.McpResilienceProperties;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.tool.Result;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.retry.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * 教师侧 MCP 调用：WebClient + Resilience4j。
 * 装饰顺序：外层 {@link Retry}，内层 {@link CircuitBreaker}，每次重试单独计入熔断窗口。
 *
 * @author zhoucong
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TeacherMcpClient {

    private final WebClient teacherMcpWebClient;
    private final TeacherMcpProperties teacherMcpProperties;
    private final McpResilienceProperties mcpResilienceProperties;
    private final CircuitBreaker teacherMcpCircuitBreaker;
    private final Retry teacherMcpRetry;

    /**
     * 通用 MCP 调用（HTTP POST）。
     *
     * @param systemType 外部系统类型
     * @param apiPath    接口路径
     * @param param      请求体（当前按 text/plain 发送，与原先 RestClient 行为一致）
     */
    public Result<String> callExternalSystem(String systemType, String apiPath, String param) {
        String op = systemType + ":" + apiPath;

        if (!teacherMcpProperties.getAllowlist().contains(op)) {
            log.warn("MCP请求被拒绝，未在白名单内，op={}", op);
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_FORBIDDEN.getCode());
            return Result.fail(EduTeacherEnum.MCP_FORBIDDEN);
        }

        if (!StringUtils.hasText(teacherMcpProperties.getAuthToken())) {
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_UNAUTHORIZED.getCode());
            return Result.fail(EduTeacherEnum.MCP_UNAUTHORIZED);
        }

        Supplier<String> perAttempt = CircuitBreaker.decorateSupplier(
                teacherMcpCircuitBreaker,
                () -> teacherMcpProperties.isMockTransportEnabled()
                        ? mockRemoteCall(systemType, apiPath, param)
                        : doHttpCall(systemType, apiPath, param));

        Supplier<String> withRetry = Retry.decorateSupplier(teacherMcpRetry, perAttempt);

        Instant start = Instant.now();
        try {
            String payload = withRetry.get();
            long elapsedMs = Duration.between(start, Instant.now()).toMillis();
            log.info("MCP调用成功，systemType={} apiPath={} elapsedMs={}", systemType, apiPath, elapsedMs);
            return Result.ok(payload);
        } catch (CallNotPermittedException e) {
            log.warn("MCP熔断拒绝调用，systemType={} apiPath={}", systemType, apiPath);
            return fallbackOrFail(systemType, apiPath, param, EduTeacherEnum.MCP_CIRCUIT_OPEN.getCode(), "circuit breaker open");
        } catch (Exception e) {
            log.warn("MCP调用失败，systemType={} apiPath={} err={}", systemType, apiPath, e.toString());
            return fallbackOrFail(systemType, apiPath, param, EduTeacherEnum.MCP_UNAVAILABLE.getCode(), "external system unavailable");
        }
    }

    private String doHttpCall(String systemType, String apiPath, String param) {
        String baseUrl = switch (systemType) {
            case "teacher" -> teacherMcpProperties.getTeacherUrl();
            default -> throw new IllegalArgumentException("unsupported systemType");
        };
        String url = baseUrl + apiPath;
        String traceId = UUID.randomUUID().toString();
        long blockTimeoutMs = Math.max(3000L, mcpResilienceProperties.getTimeoutMs() + 2000L);
        return teacherMcpWebClient.post()
                .uri(url)
                .header("Authorization", "Bearer " + teacherMcpProperties.getAuthToken())
                .header("X-Trace-Id", traceId)
                .contentType(MediaType.TEXT_PLAIN)
                .bodyValue(param)
                .retrieve()
                .onStatus(HttpStatusCode::isError, response -> response.createException().flatMap(Mono::error))
                .bodyToMono(String.class)
                .block(Duration.ofMillis(blockTimeoutMs));
    }

    private void countFailure(String systemType, String apiPath, Integer code) {
        log.warn("MCP调用统计，result=failure。 systemType={} apiPath={} code={}", systemType, apiPath, code);
    }

    private String mockRemoteCall(String systemType, String apiPath, String param) {
        if ("teacher".equals(systemType) && "/teacher/info".equals(apiPath)) {
            log.info("模拟调用OA地址：{}", teacherMcpProperties.getTeacherUrl());
            return switch (param) {
                case "zhoucong" -> """
                        {"userId":"zhoucong","userName":"周聪","grade":"普通员工","department":"研发部", "city":"湖南省岳阳市","school":"岳阳市第一中学", "stage":"高二"}
                        """;
                case "liuxianpeng" -> """
                        {"userId":"liuxianpeng","userName":"刘献朋","grade":"技术总监","department":"研发部", "city":"湖南省岳阳市","school":"岳阳市第一中学", "stage":"高三"}
                        """;
                default -> """
                        {"userId":"%s","userName":"张三","grade":"高管","department":"研发部"}
                        """.formatted(param);
            };
        }
        if ("teacher".equals(systemType) && "/teacher/class/info".equals(apiPath)) {
            log.info("模拟调用OA地址：{}", teacherMcpProperties.getTeacherUrl());
            return switch (param) {
                case "zhoucong" -> """
                        {"teacherId":"zhoucong","classInfos":[{"classId":"C201","className":"高二1班"},{"classId":"C202","className":"高二2班"},{"classId":"C203","className":"高二3班"},{"classId":"C204","className":"高二4班"}]}
                        """;
                case "liuxianpeng" -> """
                        {"teacherId":"liuxianpeng","classInfos":[{"classId":"C301","className":"高三1班"},{"classId":"C302","className":"高三2班"}]}
                        """;
                default -> """
                        {"userId":"%s","userName":"张三","grade":"高管","department":"研发部"}
                        """.formatted(param);
            };
        }
        throw new IllegalArgumentException("unsupported operation");
    }

    private Result<String> fallbackOrFail(String systemType, String apiPath, String param, Integer code, String message) {
        countFailure(systemType, apiPath, code);
        if (!teacherMcpProperties.isMockFallbackEnabled()) {
            return Result.fail(code, message);
        }
        try {
            String mock = mockRemoteCall(systemType, apiPath, param);
            log.warn("MCP降级为mock返回，systemType={} apiPath={} code={}", systemType, apiPath, code);
            return Result.ok(mock);
        } catch (Exception e) {
            return Result.fail(code, message);
        }
    }
}
