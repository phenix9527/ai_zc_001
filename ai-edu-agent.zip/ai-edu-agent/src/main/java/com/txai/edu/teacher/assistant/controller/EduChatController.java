package com.txai.edu.teacher.assistant.controller;

import com.txai.edu.teacher.assistant.agent.TeacherAssistantAgent;
import com.txai.edu.teacher.assistant.config.AiModelProperties;
import com.txai.edu.teacher.assistant.dto.ApiResponse;
import com.txai.edu.teacher.assistant.dto.req.ChatRequest;
import com.txai.edu.teacher.assistant.dto.req.TeacherLoginRequest;
import com.txai.edu.teacher.assistant.dto.resp.TeacherLoginResponse;
import com.txai.edu.teacher.assistant.config.LangfuseTraceContext;
import com.txai.edu.teacher.assistant.session.TeacherContextHolder;
import com.txai.edu.teacher.assistant.session.TeacherSessionService;
import com.txai.edu.teacher.assistant.toolmgr.EduTeacherToolManager;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * @author zhoucong
 */
@Slf4j
@RestController
@RequestMapping("/api/edu/teacher")
@RequiredArgsConstructor
public class EduChatController {

    private final TeacherAssistantAgent teacherAssistantAgent;
    private final EduTeacherToolManager eduTeacherToolManager;
    private final TeacherSessionService teacherSessionService;
    private final AiModelProperties aiModelProperties;

    /**
     * 用户登录，用于后续和其他系统的打通
     * 可以直接用教师的账号密码登录 | admin管理员账号登录 todo
     * @param req
     * @return
     */
    @PostMapping("/login")
    public ApiResponse<TeacherLoginResponse> login(@Valid @RequestBody TeacherLoginRequest req) {
        var session = teacherSessionService.createSession(req.getUsername());
        log.info("登录成功，username={}, chatId={}", req.getUsername(), session.getChatId());
        return ApiResponse.ok(TeacherLoginResponse.builder().chatId(session.getChatId()).build());
    }

    /**
     * 聊天处理
     * @param req
     * @return
     */
    @PostMapping("/handle")
    public ApiResponse<String> handleTravelRequest(@Valid @RequestBody ChatRequest req) {
        String teacherId = teacherSessionService.requireTeacherId(req.chatId());
        log.info("处理聊天请求，teacherId={}, chatId={}", teacherId, req.chatId());
        TeacherContextHolder.setTeacherId(teacherId);
        String conv = req.conversationId();
        String sessionLabel = (conv == null || conv.isBlank()) ? null : conv.trim();
        LangfuseTraceContext.set(LangfuseTraceContext.resolveTraceId(conv), sessionLabel);
        try {
            return ApiResponse.ok(teacherAssistantAgent.handleRequest(teacherId, req.chatId(), req.message()));
        } finally {
            LangfuseTraceContext.clear();
            TeacherContextHolder.clear();
        }
    }

    /**
     * 流式聊天（SSE）。与 {@link #handleTravelRequest(ChatRequest)} 共用同一套 Agent、记忆与工具；
     * 通过 {@code text/event-stream} 推送增量文本（event: delta / done / error）。
     */
    @PostMapping(value = "/handle/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter handleStream(@Valid @RequestBody ChatRequest req) {
        String teacherId = teacherSessionService.requireTeacherId(req.chatId());
        long timeoutMs = Math.max(120_000L, aiModelProperties.getTimeoutMs() + 60_000L);
        SseEmitter emitter = new SseEmitter(timeoutMs);
        String conv = req.conversationId();
        String sessionLabel = (conv == null || conv.isBlank()) ? null : conv.trim();

        CompletableFuture.runAsync(() -> {
            TeacherContextHolder.setTeacherId(teacherId);
            LangfuseTraceContext.set(LangfuseTraceContext.resolveTraceId(conv), sessionLabel);
            try {
                teacherAssistantAgent.handleRequestStream(teacherId, req.chatId(), req.message(), emitter);
            } catch (Exception e) {
                log.warn("流式会话异常", e);
                emitter.completeWithError(e);
            } finally {
                LangfuseTraceContext.clear();
                TeacherContextHolder.clear();
            }
        });

        return emitter;
    }


    /**
     * 暴露当前可用工具，便于排查工具挂载是否完整。
     */
    @GetMapping("/tools")
    public ApiResponse<List<String>> tools(@RequestParam("chatId") String chatId) {
        teacherSessionService.requireTeacherId(chatId);
        return ApiResponse.ok(eduTeacherToolManager.listRegisteredToolDescriptions());
    }




}
