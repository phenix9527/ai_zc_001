package com.txai.edu.teacher.assistant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum DBDeleteEnum {

    NOT_DELETED(0),
    DELETED(1), ;

    private Integer code;
}
