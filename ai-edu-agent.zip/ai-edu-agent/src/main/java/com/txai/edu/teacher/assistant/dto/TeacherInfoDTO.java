package com.txai.edu.teacher.assistant.dto;

import lombok.Data;

/**
 * @author zhoucong
 */
@Data
public class TeacherInfoDTO {
    private String userId;
    private String userName;
    private String city;
    private String school;
    private String stage;
}
