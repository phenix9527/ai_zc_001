package com.txai.edu.teacher.assistant.exception;

/**
 * @author zhoucong
 */
public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}
