package com.txai.edu.teacher.assistant.skill;

import dev.langchain4j.agent.tool.P;
import dev.langchain4j.agent.tool.Tool;
import dev.langchain4j.service.MemoryId;
import com.txai.edu.teacher.assistant.dto.ErrorWordPaperDTO;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.service.PaperReviewRenderer;
import com.txai.edu.teacher.assistant.service.PaperReviewService;
import com.txai.edu.teacher.assistant.tool.Result;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author zhoucong
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaperReviewSkill {

    /** 工具返回中包裹「服务端固定一句汇总」的标记，供模型在回复末尾原样复述。 */
    private static final String LIB_TOOL_VERBATIM_START = "【题库组卷_TOOL_RETURN_VERBATIM_START】";
    private static final String LIB_TOOL_VERBATIM_END = "【题库组卷_TOOL_RETURN_VERBATIM_END】";
    private static final String REPLACE_TOOL_VERBATIM_START = "【同词换题_TOOL_RETURN_VERBATIM_START】";
    private static final String REPLACE_TOOL_VERBATIM_END = "【同词换题_TOOL_RETURN_VERBATIM_END】";
    private final PaperReviewService paperReviewService;
    private final PaperReviewRenderer paperReviewRenderer;

    @Tool(name = "genPaperReviewErrorQuestionSkill",
            value = "原题组卷：用户说「原题组卷」或要基于历史原题出卷时必须调用；按错词错误率高到低的优先顺序抽取原题，不做按词加权配题；总量按 totalCount 截断。")
    public String genPaperReviewErrorQuestionSkill(@MemoryId String chatId,
                                                   @P("选中的错词ID列表（建议按错误率降序）") List<String> word,
                                                   @P("目标班级ID列表") List<String> classIds,
                                                   @P("练习记录ID列表") List<String> practiceIds,
                                                   @P("查询开始时间 (YYYY-MM-DD)") String startTime,
                                                   @P("查询结束时间 (YYYY-MM-DD)") String endTime,
                                                   @P("期望生成的总题数") Integer totalCount) {
        Result<ErrorWordPaperDTO> result = paperReviewService.genPaperReviewErrorQuestion(chatId, word, classIds, practiceIds, startTime, endTime, totalCount);
        if (result.success()) {
            return paperReviewRenderer.renderErrorPaperPreview(result.data());
        }
        if (result.message() != null && result.message().contains("请先提供按错误率降序排列的错词列表")) {
            return result.message();
        }
        log.warn("调用Tool：原题组卷失败 classIds={} practiceIds={} startTime={} endTime={} totalCount={} code={}",
                classIds, practiceIds, startTime, endTime, totalCount, result.code());
        return "原题组卷暂时不可用，请稍后重试。";
    }

    @Tool(name = "genPaperReviewQuestionLibrarySkill",
            value = "新题/题库组卷：用户说「新题」「新题组卷」「题库组卷」或同义须调本工具；按错词、学段与题库业务题型从题库抽题生成预览；题型须为教室端勾选项名称（本期仅语境填词、单句语法填空），勿用选择题/填空等通用叫法；组题策略为错误率高的错词多配题。**工具返回的 Markdown 表即为最终题表**：返回几题即几题，勿自行补行、勿再造第二张预览表。")
    public String genPaperReviewQuestionLibrarySkill(@MemoryId String chatId,
                                                     @P("选中的错词ID列表") List<String> wordIds,
                                                     @P("学段编码：无独立编码时填 getTeacherInfo 返回 JSON 中的 stage 字段值即可") String stageId,
                                                     @P("学段展示名：可与 stageId 相同，通常即教师档案中的 stage（如 高中、高二）") String stageName,
                                                     @P("题库业务题型名称列表，与教室端「题库组卷」勾选项一致。本期仅「语境填词」「单句语法填空」；未传或空列表时默认二者都抽；勿填选择题/阅读理解等通用题型。") List<String> questionTypes,
                                                     @P("与 wordIds 顺序一一对应的错误率，取值同 listWrongWordSortedByErrorRate 返回的 errorRate（如 88 或 0.72）；可选。与 wordIds 等长时按错误率加权分配总题数，否则均分。") List<String> wordErrorRates,
                                                     @P("期望生成的总题数") Integer totalCount) {
        Result<ErrorWordPaperDTO> result = paperReviewService.genPaperReviewQuestionLibrary(
                chatId, wordIds, stageId, stageName, questionTypes, wordErrorRates, totalCount);
        if (result.success()) {
            return paperReviewRenderer.renderLibraryPaperPreview(result.data());
        }
        log.warn("调用Tool：genPaperReviewQuestionLibrarySkill失败 stageId={} stageName={} totalCount={} code={}",
                stageId, stageName, totalCount, result.code());
        String failMsg = "题库组卷暂时不可用，请稍后重试。";
        return failMsg + "\n\n" + LIB_TOOL_VERBATIM_START + "\n" + failMsg + "\n" + LIB_TOOL_VERBATIM_END;
    }

    @Tool(name = "replaceSingleQuestion",
            value = "同词换题：用户对预览卷中某一题要求「换一题」「换题」且错词不变时调用；入参为当前预览卷 **paperId**（须与上一轮预览 Markdown 末尾「试卷ID」一致，勿填教师姓名）、被替换行的题目序号 **questionNo**（与预览表「序号」列一致）、错词 **wrongWord**（与预览表「错词」列一致）。服务端会按教师+序号+错词从预览库反查真实试卷 ID。**工具返回的 Markdown 表即为最终预览**：勿自行补题或改写表格单元格。")
    public String replaceSingleQuestion(@MemoryId String chatId,
                                        @P("试卷ID：与上一轮组卷/换题预览末尾「试卷ID」行一致") String paperId,
                                        @P("题目序号，与预览表「序号」列一致") Integer questionNo,
                                        @P("错词，与预览表「错词」列一致") String wrongWord) {
        Result<ErrorWordPaperDTO> result = paperReviewService.replaceSingleQuestion(chatId, paperId, questionNo, wrongWord);
        if (!result.success()) {
            if (result.code() != null && result.code() == EduTeacherEnum.REPLACE_SINGLE_QUESTION_PARAM_INVALID.getCode()) {
                return result.message() != null ? result.message() : "同词换题参数无效。";
            }
            log.warn("调用Tool：replaceSingleQuestion失败 paperId={} questionNo={} wrongWord={} code={}",
                    paperId, questionNo, wrongWord, result.code());
            String failMsg = "同词换题暂时不可用，请稍后重试。";
            return failMsg + "\n\n" + REPLACE_TOOL_VERBATIM_START + "\n" + failMsg + "\n" + REPLACE_TOOL_VERBATIM_END;
        }
        String body = paperReviewRenderer.renderReplaceQuestionPreview(result.data());
        return body + "\n\n" + REPLACE_TOOL_VERBATIM_START + "\n" + body + "\n" + REPLACE_TOOL_VERBATIM_END;
    }
}
