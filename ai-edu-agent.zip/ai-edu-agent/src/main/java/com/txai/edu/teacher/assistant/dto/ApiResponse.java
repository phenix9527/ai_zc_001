package com.txai.edu.teacher.assistant.dto;

/**
 * @author zhoucong
 */
public record ApiResponse<T>(int code, String msg, T data) {

    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(0, "ok", data);
    }

    public static <T> ApiResponse<T> err(int code, String msg) {
        return new ApiResponse<>(code, msg, null);
    }
}
