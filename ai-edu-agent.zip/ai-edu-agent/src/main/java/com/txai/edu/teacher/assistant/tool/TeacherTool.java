package com.txai.edu.teacher.assistant.tool;

import com.txai.edu.teacher.assistant.dto.TeacherClassDTO;
import com.txai.edu.teacher.assistant.dto.TeacherInfoDTO;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.mcp.TeacherMcpAdapter;
import com.txai.edu.teacher.assistant.session.TeacherContextHolder;
import dev.langchain4j.agent.tool.Tool;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * @author zhoucong
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TeacherTool {


    private final TeacherMcpAdapter teacherMcpAdapter;

    @Tool(name = "getTeacherInfo", value = "获取指定教师的信息")
    public Result<TeacherInfoDTO> getTeacherInfo(String teacherId) {
        String contextTeacherId = TeacherContextHolder.getTeacherId();
        String resolvedTeacherId = StringUtils.hasText(contextTeacherId) ? contextTeacherId : teacherId;
        if (StringUtils.hasText(contextTeacherId) && StringUtils.hasText(teacherId) && !contextTeacherId.equals(teacherId)) {
            log.warn("Tool入参teacherId与会话teacherId不一致，优先使用会话值。arg={}, session={}", teacherId, contextTeacherId);
        }
        log.info("调用Tool：获取教师信息，teacherId={}", resolvedTeacherId);
        Result<TeacherInfoDTO> result = teacherMcpAdapter.getTeacherInfo(resolvedTeacherId);
        if (result.success()) {
            return result;
        }
        log.warn("获取指定教师的信息失败，teacher={} code={}", resolvedTeacherId, result.code());
        return Result.fail(EduTeacherEnum.GET_TEACHER_INFO_FAIL);
    }

    @Tool(name = "listTeacherRelatedClasses", value = "获取教师关联的班级列表")
    public Result<TeacherClassDTO> listTeacherRelatedClasses(String teacherId) {
        String contextTeacherId = TeacherContextHolder.getTeacherId();
        String resolvedTeacherId = StringUtils.hasText(contextTeacherId) ? contextTeacherId : teacherId;
        if (StringUtils.hasText(contextTeacherId) && StringUtils.hasText(teacherId) && !contextTeacherId.equals(teacherId)) {
            log.warn("Tool入参teacherId与会话teacherId不一致，优先使用会话值。arg={}, session={}", teacherId, contextTeacherId);
        }
        log.info("调用Tool：获取教师关联的班级列表，teacherId={}", resolvedTeacherId);
        Result<TeacherClassDTO> result = teacherMcpAdapter.getTeacherRelatedClasses(resolvedTeacherId);
        if (result.success()) {
            return result;
        }
        log.warn("获取教师关联的班级列表失败，teacher={} code={}", resolvedTeacherId, result.code());
        return Result.fail(EduTeacherEnum.GET_TEACHER_CLASS_INFO_FAIL);
    }
}
