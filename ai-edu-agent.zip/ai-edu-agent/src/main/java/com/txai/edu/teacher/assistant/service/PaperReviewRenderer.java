package com.txai.edu.teacher.assistant.service;

import com.txai.edu.teacher.assistant.dto.ErrorWordPaperDTO;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

@Component
public class PaperReviewRenderer {

    public String renderErrorPaperPreview(ErrorWordPaperDTO dto) {
        return renderPaperPreviewTable(dto, "### 组卷预览", "原题组卷未返回有效题目。");
    }

    /**
     * 题库/新题组卷 MCP 返回结构与 {@link #renderErrorPaperPreview} 相同，单独标题便于与会话中「原题」预览区分，
     * 并减少模型用错词列表与题干自行「配对」另造一张表的概率。
     */
    public String renderLibraryPaperPreview(ErrorWordPaperDTO dto) {
        return renderPaperPreviewTable(dto, "### 新题组卷预览", "新题组卷未返回有效题目。");
    }

    /** 同词换题：MCP 返回单题结构，与组卷预览表头一致。 */
    public String renderReplaceQuestionPreview(ErrorWordPaperDTO dto) {
        return renderPaperPreviewTable(dto, "### 同词换题预览", "同词换题未返回有效题目。");
    }

    private String renderPaperPreviewTable(ErrorWordPaperDTO dto, String markdownTitle, String emptyMessage) {
        if (dto == null || CollectionUtils.isEmpty(dto.getErrorWordPapers())) {
            return emptyMessage;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(markdownTitle).append("\n\n")
                .append("| 序号 | 错词 | 题目内容 | 难度 | 答案解析 |\n")
                .append("| --- | --- | --- | --- | --- |\n");
        for (ErrorWordPaperDTO.ErrorWordPaper paper : dto.getErrorWordPapers()) {
            String questionNo = valueOrDash(paper.getQuestionNo());
            String wrongWord = sanitizeCell(paper.getWrongWord());
            String content = sanitizeCell(paper.getQuestionContent());
            String difficulty = "★".repeat(Math.max(0, Math.min(5, paper.getDifficultyStar() == null ? 0 : paper.getDifficultyStar())));
            String analysis = sanitizeCell(paper.getAnswerAnalysis());
            sb.append("| ").append(questionNo)
                    .append(" | ").append(wrongWord)
                    .append(" | ").append(content)
                    .append(" | ").append(difficulty.isEmpty() ? "-" : difficulty)
                    .append(" | ").append(analysis)
                    .append(" |\n");
        }
        String paperIdHint = dto.getErrorWordPapers().stream()
                .map(ErrorWordPaperDTO.ErrorWordPaper::getPaperId)
                .filter(StringUtils::hasText)
                .findFirst()
                .orElse(null);
        if (StringUtils.hasText(paperIdHint)) {
            sb.append("\n\n**试卷ID**（同词换题时工具参数 `paperId` 请填此值）：`")
                    .append(paperIdHint.replace("`", "'"))
                    .append("`");
        }
        return sb.toString().trim();
    }

    private static String sanitizeCell(String value) {
        if (value == null || value.isBlank()) {
            return "-";
        }
        return value.replace("|", "\\|").replace("\n", "<br>");
    }

    private static String valueOrDash(Integer value) {
        return value == null ? "-" : String.valueOf(value);
    }
}
