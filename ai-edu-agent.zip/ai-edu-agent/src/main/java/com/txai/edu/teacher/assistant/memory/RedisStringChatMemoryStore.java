package com.txai.edu.teacher.assistant.memory;

import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.ChatMessageDeserializer;
import dev.langchain4j.data.message.ChatMessageSerializer;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * 使用 Spring Data Redis {@link StringRedisTemplate} 持久化 LangChain4j 对话消息，
 * 与项目现有 Redis 集群/单机配置共用连接。
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RedisStringChatMemoryStore implements ChatMemoryStore {

    private final StringRedisTemplate stringRedisTemplate;
    private final TeacherChatMemoryProperties properties;

    @Override
    public List<ChatMessage> getMessages(Object memoryId) {
        String key = toKey(memoryId);
        try {
            String json = stringRedisTemplate.opsForValue().get(key);
            if (!StringUtils.hasText(json)) {
                return new ArrayList<>();
            }
            try {
                return ChatMessageDeserializer.messagesFromJson(json);
            } catch (Exception parse) {
                log.warn("ChatMemory JSON 反序列化失败，将视为空会话。memoryId={}", memoryId, parse);
                return new ArrayList<>();
            }
        } catch (Exception e) {
            log.warn("Redis 读取 ChatMemory 失败，memoryId={}", memoryId, e);
            return new ArrayList<>();
        }
    }

    @Override
    public void updateMessages(Object memoryId, List<ChatMessage> messages) {
        String key = toKey(memoryId);
        String json = ChatMessageSerializer.messagesToJson(messages);
        Duration ttl = Duration.ofMinutes(Math.max(1, properties.getTtlMinutes()));
        try {
            stringRedisTemplate.opsForValue().set(key, json, ttl);
        } catch (Exception e) {
            log.warn("Redis 写入 ChatMemory 失败，memoryId={}", memoryId, e);
            throw new IllegalStateException("Redis ChatMemory 写入失败", e);
        }
    }

    @Override
    public void deleteMessages(Object memoryId) {
        String key = toKey(memoryId);
        try {
            stringRedisTemplate.delete(key);
        } catch (Exception e) {
            log.warn("Redis 删除 ChatMemory 失败，memoryId={}", memoryId, e);
        }
    }

    private String toKey(Object memoryId) {
        if (memoryId == null || !StringUtils.hasText(memoryId.toString())) {
            throw new IllegalArgumentException("memoryId (chatId) 不能为空");
        }
        return properties.getKeyPrefix() + memoryId.toString().trim();
    }
}
