package com.txai.edu.teacher.assistant.toolmgr;

import com.google.common.collect.Lists;
import com.txai.edu.teacher.assistant.skill.PaperReviewSkill;
import com.txai.edu.teacher.assistant.tool.PaperPracticeResultTool;
import com.txai.edu.teacher.assistant.tool.TeacherTool;
import lombok.RequiredArgsConstructor;
import org.springframework.aop.support.AopUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;

/**
 * @author zhoucong
 */
@Component
@RequiredArgsConstructor
public class EduTeacherToolManager {

    private final TeacherTool teacherTool;
    private final PaperReviewSkill paperReviewSkill;
    private final PaperPracticeResultTool paperPracticeResultTool;

    /**
     * 枚举当前挂载工具，用于调试与可观测性。
     */
    public List<String> listRegisteredToolDescriptions() {
        List<String> out = Lists.newArrayList();
        collect(teacherTool, out);
        collect(paperPracticeResultTool, out);
        collect(paperReviewSkill, out);
        return out;
    }

    /**
     * 反射读取 @Tool 描述，生成可读的工具清单。
     */
    private static void collect(Object bean, List<String> out) {
        Class<?> type = AopUtils.getTargetClass(bean);
        for (Method method : type.getMethods()) {
            var ann = method.getAnnotation(dev.langchain4j.agent.tool.Tool.class);
            if (ann != null) {
                String desc = ann.value() == null || ann.value().length == 0
                        ? ""
                        : String.join(" ", ann.value());
                out.add(method.getName() + ": " + desc);
            }
        }
    }
}
