package com.txai.edu.teacher.assistant.session;

import com.alibaba.fastjson2.JSON;
import com.txai.edu.teacher.assistant.config.TeacherSessionProperties;
import com.txai.edu.teacher.assistant.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * chatId -> teacherId 会话管理。
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TeacherSessionService {

    private final StringRedisTemplate stringRedisTemplate;
    private final TeacherSessionProperties teacherSessionProperties;
    private final Map<String, TeacherChatSession> localFallback = new ConcurrentHashMap<>();

    public TeacherChatSession createSession(String username) {
        String chatId = UUID.randomUUID().toString();
        long now = System.currentTimeMillis();
        TeacherChatSession session = TeacherChatSession.builder()
                .chatId(chatId)
                .teacherId(username)
                .username(username)
                .loginAt(now)
                .lastActiveAt(now)
                .build();
        saveSession(session);
        return session;
    }

    public String requireTeacherId(String chatId) {
        if (!StringUtils.hasText(chatId)) {
            throw new BusinessException("chatId 不能为空，请先登录");
        }
        TeacherChatSession session = getSession(chatId);
        if (session == null || !StringUtils.hasText(session.getTeacherId())) {
            throw new BusinessException("会话不存在或已过期，请重新登录");
        }
        touchSession(session);
        return session.getTeacherId();
    }

    private TeacherChatSession getSession(String chatId) {
        String key = buildKey(chatId);
        try {
            String val = stringRedisTemplate.opsForValue().get(key);
            if (!StringUtils.hasText(val)) {
                return localFallback.get(chatId);
            }
            return JSON.parseObject(val, TeacherChatSession.class);
        } catch (Exception e) {
            log.warn("Redis读取会话失败，降级本地内存。chatId={}", chatId, e);
            return localFallback.get(chatId);
        }
    }

    private void saveSession(TeacherChatSession session) {
        Duration ttl = Duration.ofMinutes(Math.max(1, teacherSessionProperties.getTtlMinutes()));
        String key = buildKey(session.getChatId());
        String val = JSON.toJSONString(session);
        try {
            stringRedisTemplate.opsForValue().set(key, val, ttl);
        } catch (Exception e) {
            log.warn("Redis写入会话失败，降级本地内存。chatId={}", session.getChatId(), e);
        }
        localFallback.put(session.getChatId(), session);
    }

    private void touchSession(TeacherChatSession session) {
        session.setLastActiveAt(System.currentTimeMillis());
        saveSession(session);
    }

    private String buildKey(String chatId) {
        return teacherSessionProperties.getKeyPrefix() + chatId;
    }
}
