package com.txai.edu.teacher.assistant.mcp;

import com.alibaba.fastjson2.JSON;
import com.txai.edu.teacher.assistant.dto.TeacherClassDTO;
import com.txai.edu.teacher.assistant.dto.TeacherInfoDTO;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.tool.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * @author zhoucong
 */
@Component
@RequiredArgsConstructor
public class TeacherMcpAdapter {

    private final TeacherMcpClient teacherMcpClient;

    public Result<TeacherInfoDTO> getTeacherInfo(String teacherId) {
        Result<String> raw = teacherMcpClient.callExternalSystem("teacher", "/teacher/info", teacherId);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }

        try {
            TeacherInfoDTO teacher = JSON.parseObject(raw.data(), TeacherInfoDTO.class);
            if (teacher == null) {
                return Result.fail(EduTeacherEnum.GET_TEACHER_INFO_FAIL);
            }
            return Result.ok(teacher);
        } catch (Exception e) {
            return Result.fail(EduTeacherEnum.GET_TEACHER_INFO_FAIL);
        }

    }

    public Result<TeacherClassDTO> getTeacherRelatedClasses(String teacherId) {

        Result<String> raw = teacherMcpClient.callExternalSystem("teacher", "/teacher/class/info", teacherId);
        if (!raw.success()) {
            return Result.fail(raw.code(), raw.message());
        }

        try {
            TeacherClassDTO teacherClass = JSON.parseObject(raw.data(), TeacherClassDTO.class);
            if (teacherClass == null) {
                return Result.fail(EduTeacherEnum.GET_TEACHER_CLASS_INFO_FAIL);
            }
            return Result.ok(teacherClass);
        } catch (Exception e) {
            return Result.fail(EduTeacherEnum.GET_TEACHER_CLASS_INFO_FAIL);
        }
    }
}
