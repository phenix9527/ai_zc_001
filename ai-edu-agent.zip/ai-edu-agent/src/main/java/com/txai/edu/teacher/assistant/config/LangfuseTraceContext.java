package com.txai.edu.teacher.assistant.config;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * 单次 HTTP 请求内把「会话级 trace」从 Controller 传到 {@link dev.langchain4j.model.chat.listener.ChatModelListener}，
 * 并将前端的 {@code conversationId} 规范为 Langfuse Trace id（UUID）。
 */
public final class LangfuseTraceContext {

    private static final ThreadLocal<String> TRACE_ID = new ThreadLocal<>();
    /** 前端原始 conversationId，写入 Langfuse Trace.sessionId，便于按会话筛选 */
    private static final ThreadLocal<String> SESSION_LABEL = new ThreadLocal<>();

    private LangfuseTraceContext() {
    }

    public static void set(String traceId, String sessionLabel) {
        TRACE_ID.set(traceId);
        SESSION_LABEL.set(sessionLabel);
    }

    public static String traceId() {
        return TRACE_ID.get();
    }

    public static String sessionLabel() {
        return SESSION_LABEL.get();
    }

    public static void clear() {
        TRACE_ID.remove();
        SESSION_LABEL.remove();
    }

    /**
     * @param conversationId 非空时作为稳定会话键；为空则每次调用返回新 UUID（每请求一条 Trace）
     */
    public static String resolveTraceId(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) {
            return UUID.randomUUID().toString();
        }
        String s = conversationId.trim();
        if (s.length() > 256) {
            s = s.substring(0, 256);
        }
        try {
            return UUID.fromString(s).toString();
        } catch (IllegalArgumentException ignored) {
            return UUID.nameUUIDFromBytes(s.getBytes(StandardCharsets.UTF_8)).toString();
        }
    }
}
