package com.txai.edu.teacher.assistant.dto.req;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * @author admin
 */
public record ChatRequest(
        @NotBlank(message = "chatId 不能为空") String chatId,
        @NotBlank(message = "message 不能为空") String message,
        /**
         * 前端「一个会话框」的稳定 ID（建议 UUID）。多次 chat 传同一值则 Langfuse 合并为一条 Trace。
         */
        @Size(max = 256) String conversationId) {}