package com.txai.edu.teacher.assistant.memory;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 教师对话 ChatMemory（Redis）配置。
 */
@Data
@ConfigurationProperties(prefix = "teacher.chat.memory")
public class TeacherChatMemoryProperties {

    /**
     * Redis key 前缀，完整 key = prefix + chatId（与登录会话 chatId 对齐）。
     */
    private String keyPrefix = "edu:chat:memory:";

    /**
     * 记忆在 Redis 中的 TTL；每次写入会刷新过期时间。
     */
    private int ttlMinutes = 120;

    /**
     * 滑动窗口保留的最大消息条数（含 user/ai/tool 等）。
     */
    private int maxMessages = 40;
}
