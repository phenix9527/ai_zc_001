package com.txai.edu.teacher.assistant.service;

import com.txai.edu.teacher.assistant.enums.DBDeleteEnum;
import com.txai.edu.teacher.assistant.exception.BusinessException;
import com.txai.edu.teacher.assistant.mcp.PaperPracticeResultMcpAdapter;
import com.txai.edu.teacher.assistant.dto.ErrorWordPaperDTO;
import com.txai.edu.teacher.assistant.entity.po.PaperQuestionPreviewPO;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.mapper.PaperQuestionPreviewMapper;
import com.txai.edu.teacher.assistant.session.TeacherContextHolder;
import com.txai.edu.teacher.assistant.session.TeacherSessionService;
import com.txai.edu.teacher.assistant.tool.Result;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.IntStream;

@Service
@Slf4j
@RequiredArgsConstructor
public class PaperReviewService {

    public static final List<String> SUPPORTED_LIBRARY_QUESTION_TYPES = List.of("语境填词", "单句语法填空");
    private static final int GEN_PAPER_TYPE_ERROR = 1;
    private static final int GEN_PAPER_TYPE_LIBRARY = 2;
    private static final int QUESTION_REPLACE_TYPE = 3;
    private final PaperPracticeResultMcpAdapter paperPracticeResultMcpAdapter;
    private final PaperQuestionPreviewMapper paperQuestionPreviewMapper;
    private final TeacherSessionService teacherSessionService;

    public Result<ErrorWordPaperDTO> genPaperReviewErrorQuestion(String chatId,
                                                                 List<String> words,
                                                                 List<String> classIds,
                                                                 List<String> practiceIds,
                                                                 String startTime,
                                                                 String endTime,
                                                                 Integer totalCount) {
        int resolvedTotal = totalCount != null && totalCount > 0 ? totalCount : 20;
        List<String> orderedWords = normalizeWordList(words);
        if (orderedWords.isEmpty()) {
            return Result.fail(EduTeacherEnum.GET_PRACTICE_ERROR_WORD_INVALID.getCode(),
                    "原题组卷预览待生成：请先提供按错误率降序排列的错词列表。");
        }




        Result<ErrorWordPaperDTO> errorWordPaperDTOResult = paperPracticeResultMcpAdapter.genPaperReviewErrorQuestion(
                orderedWords, classIds, practiceIds, startTime, endTime, resolvedTotal);
        if (errorWordPaperDTOResult.success()) {
            String teacherId = resolveTeacherIdForPersist(chatId);
            persistErrorPaperPreview(teacherId, errorWordPaperDTOResult.data(), GEN_PAPER_TYPE_ERROR, resolvedTotal);
        }

        return errorWordPaperDTOResult;
    }

    public Result<ErrorWordPaperDTO> genPaperReviewQuestionLibrary(String chatId,
                                                        List<String> wordIds,
                                                        String stageId,
                                                        String stageName,
                                                        List<String> questionTypes,
                                                        List<String> wordErrorRates,
                                                        Integer totalCount) {
        int resolvedTotal = totalCount != null && totalCount > 0 ? totalCount : 20;
        if (wordIds == null || wordIds.isEmpty()) {
            return Result.fail(EduTeacherEnum.GEN_LIBRARY_PAPER_ERROR_WORD_ISNULL);
        }
        List<String> resolvedTypes = resolveLibraryQuestionTypes(questionTypes);
        int[] perWord = allocateQuestionCountsByErrorRates(wordIds, wordErrorRates, resolvedTotal);
        Result<ErrorWordPaperDTO> libraryResult = paperPracticeResultMcpAdapter.genPaperReviewQuestionLibrary(
                stageId, stageName, wordIds, resolvedTypes, wordErrorRates, resolvedTotal, perWord);
        if (libraryResult.success()) {
            String teacherId = resolveTeacherIdForPersist(chatId);
            persistErrorPaperPreview(teacherId, libraryResult.data(), GEN_PAPER_TYPE_LIBRARY, resolvedTotal);
        }
        return libraryResult;
    }

    public Result<ErrorWordPaperDTO> replaceSingleQuestion(String chatId, String paperId, Integer questionNo, String wrongWord) {
        if (!StringUtils.hasText(paperId) || questionNo == null || questionNo < 1 || !StringUtils.hasText(wrongWord)) {
            return Result.fail(EduTeacherEnum.REPLACE_SINGLE_QUESTION_PARAM_INVALID);
        }
        String teacherId = resolveTeacherIdForPersist(chatId);
        String effectivePaperId = resolvePaperIdForReplace(teacherId, paperId.trim(), questionNo, wrongWord.trim());
        Result<ErrorWordPaperDTO> replaceResult = paperPracticeResultMcpAdapter.replaceSingleQuestion(
                effectivePaperId, questionNo, wrongWord.trim());
        if (replaceResult.success()) {
            // 须先软删旧预览行再插入新行：同词换题新旧两行 question_no、wrong_word 相同，若先插入再删会误伤新行。
            markReplacedPreviewRowDeleted(teacherId, effectivePaperId, questionNo, wrongWord.trim());
            persistErrorPaperPreview(teacherId, replaceResult.data(), QUESTION_REPLACE_TYPE, 1);
        }
        return replaceResult;
    }

    /**
     * 预览表未展示 paperId 时模型易把教师名等误当作 paperId；优先用库中未删除预览行反查真实 paper_id。
     */
    private String resolvePaperIdForReplace(String teacherId, String requestedPaperId, Integer questionNo, String wrongWord) {
        if (!StringUtils.hasText(teacherId)) {
            return normalizePaperIdForDb(requestedPaperId);
        }
        String tid = normalizeTeacherIdForDb(teacherId);
        String ww = truncateWrongWordForDb(wrongWord);
        try {
            String fromDb = paperQuestionPreviewMapper.findLatestActivePaperId(tid, questionNo, ww);
            if (StringUtils.hasText(fromDb)) {
                if (!fromDb.equals(requestedPaperId)) {
                    log.info("换题 paperId 以预览库为准：请求={} 解析为={} questionNo={} wrongWord={}",
                            requestedPaperId, fromDb, questionNo, ww);
                }
                return fromDb;
            }
        } catch (Exception e) {
            log.warn("换题解析 paperId 查询异常，回退请求值。questionNo={} err={}", questionNo, e.getMessage());
        }
        return normalizePaperIdForDb(requestedPaperId);
    }

    /**
     * 换题成功后，将预览表中「被替换」的那一行逻辑删除（与 {@link #persistErrorPaperPreview} 入库维度对齐：teacher_id、paper_id、question_no、wrong_word）。
     */
    private void markReplacedPreviewRowDeleted(String teacherId, String paperId, Integer questionNo, String wrongWord) {
        if (!StringUtils.hasText(teacherId)) {
            log.warn("换题 soft-delete 跳过：无 teacherId，paperId={} questionNo={}", paperId, questionNo);
            return;
        }
        if (questionNo == null || questionNo < 1) {
            log.warn("换题 soft-delete 跳过：questionNo 无效 paperId={} questionNo={}", paperId, questionNo);
            return;
        }
        String tid = normalizeTeacherIdForDb(teacherId);
        String pid = normalizePaperIdForDb(paperId);
        String ww = truncateWrongWordForDb(wrongWord);
        try {
            int n = paperQuestionPreviewMapper.logicDeleteReplacedPreviewRow(tid, pid, questionNo, ww);
            if (n == 1) {
                log.info("换题 soft-delete 成功 teacherId={} paperId={} questionNo={} wrongWord={}", tid, pid, questionNo, ww);
            } else {
                log.warn("换题 soft-delete 影响行数≠1，实际={} teacherId={} paperId={} questionNo={} wrongWord={}",
                        n, tid, pid, questionNo, ww);
            }
        } catch (Exception e) {
            log.error("换题 soft-delete 异常 teacherId={} paperId={} questionNo={} err={}",
                    tid, pid, questionNo, e.getMessage(), e);
        }
    }

    /**
     * 工具可能在 LangChain4j 内部线程执行，{@link TeacherContextHolder} 为空；
     * 此时用会话 {@code chatId} 从 Redis/本地会话解析教师 ID（与 {@link TeacherSessionService#requireTeacherId} 一致）。
     */
    private String resolveTeacherIdForPersist(String chatId) {
        String fromThread = TeacherContextHolder.getTeacherId();
        if (StringUtils.hasText(fromThread)) {
            return fromThread;
        }
        if (!StringUtils.hasText(chatId)) {
            return null;
        }
        try {
            return teacherSessionService.requireTeacherId(chatId);
        } catch (BusinessException e) {
            log.warn("落库解析 teacherId 失败：chatId 无有效会话。chatId={} msg={}", chatId, e.getMessage());
            return null;
        } catch (Exception e) {
            log.warn("落库解析 teacherId 异常 chatId={}", chatId, e);
            return null;
        }
    }

    private void persistErrorPaperPreview(String teacherId, ErrorWordPaperDTO dto, int genPaperType, int totalCount) {
        if (!StringUtils.hasText(teacherId)) {
            log.warn("paper_question_preview 跳过落库：无 teacherId（ThreadLocal 未设置且 chatId 未解析到会话）");
            return;
        }
        if (dto == null || CollectionUtils.isEmpty(dto.getErrorWordPapers())) {
            return;
        }
        String paperId = resolveErrorPaperId(dto);
        List<ErrorWordPaperDTO.ErrorWordPaper> papers = dto.getErrorWordPapers();
        List<PaperQuestionPreviewPO> rows = IntStream.range(0, papers.size())
                .mapToObj(i -> {
                    ErrorWordPaperDTO.ErrorWordPaper item = papers.get(i);
                    PaperQuestionPreviewPO po = new PaperQuestionPreviewPO();
                    po.setTeacherId(normalizeTeacherIdForDb(teacherId));
                    po.setPaperId(paperId);
                    po.setGenPaperType(genPaperType);
                    po.setQuestionNo(item.getQuestionNo() != null ? item.getQuestionNo() : i + 1);
                    po.setQuestionId(normalizeQuestionIdForDb(item.getQuestionId()));
                    po.setWrongWord(truncateWrongWordForDb(item.getWrongWord()));
                    po.setQuestionContent(item.getQuestionContent());
                    po.setAnswerAnalysis(item.getAnswerAnalysis());
                    po.setDifficultyStar(item.getDifficultyStar() != null ? item.getDifficultyStar() : 0);
                    po.setExtension("");
                    po.setIsDeleted(DBDeleteEnum.NOT_DELETED.getCode());
                    return po;
                })
                .toList();
        safeBatchInsert(rows, teacherId, paperId, genPaperType, totalCount);
    }

//    private void persistLibraryPaperPreview(String teacherId,
//                                            String preview,
//                                            String stageId,
//                                            String stageName,
//                                            List<String> questionTypes,
//                                            List<String> wordIds,
//                                            List<String> wordErrorRates,
//                                            int totalCount) {
//        if (!StringUtils.hasText(teacherId)) {
//            return;
//        }
//        String paperId = resolveLibraryPaperId(preview);
//        Map<String, Object> extension = new LinkedHashMap<>();
//        extension.put("stageId", stageId);
//        extension.put("stageName", stageName);
//        extension.put("questionTypes", questionTypes == null ? List.of() : questionTypes);
//        extension.put("wordIds", wordIds == null ? List.of() : wordIds);
//        extension.put("wordErrorRates", wordErrorRates == null ? List.of() : wordErrorRates);
//        extension.put("preview", preview);
//        extension.put("totalCount", totalCount);
//
//        PaperQuestionPreviewPO po = new PaperQuestionPreviewPO();
//        po.setTeacherId(teacherId);
//        po.setPaperId(paperId);
//        po.setGenPaperType(GEN_PAPER_TYPE_LIBRARY);
//        po.setQuestionNo(1);
//        po.setQuestionId("LIBRARY_PREVIEW");
//        po.setWrongWord("");
//        po.setQuestionContent(preview);
//        po.setAnswerAnalysis("-");
//        po.setDifficultyStar(0);
//        po.setExtension(JSON.toJSONString(extension));
//        po.setIsDeleted(DBDeleteEnum.NOT_DELETED.getCode());
//        safeBatchInsert(List.of(po), teacherId, paperId, GEN_PAPER_TYPE_LIBRARY, totalCount);
//    }

    private void safeBatchInsert(List<PaperQuestionPreviewPO> rows,
                                 String teacherId,
                                 String paperId,
                                 int genPaperType,
                                 int totalCount) {
        if (CollectionUtils.isEmpty(rows)) {
            return;
        }
        try {
            paperQuestionPreviewMapper.batchInsert(rows);
        } catch (Exception e) {
            log.error("paper_question_preview落库失败 teacherId={} paperId={} genPaperType={} totalCount={} err={}",
                    teacherId, paperId, genPaperType, totalCount, e.getMessage(), e);
        }
    }

    /**
     * 表字段 {@code paper_id} 为 varchar(32)。历史实现使用 {@code ERR-} + UUID（40 字符）会导致 INSERT 失败且仅打 error 日志。
     */
    private static String resolveErrorPaperId(ErrorWordPaperDTO dto) {
        if (dto == null || CollectionUtils.isEmpty(dto.getErrorWordPapers())) {
            return newPaperId32();
        }
        return dto.getErrorWordPapers().stream()
                .map(ErrorWordPaperDTO.ErrorWordPaper::getPaperId)
                .filter(StringUtils::hasText)
                .findFirst()
                .map(PaperReviewService::normalizePaperIdForDb)
                .orElseGet(PaperReviewService::newPaperId32);
    }

    /** 无连字符 UUID，长度 32，符合 paper_id varchar(32)。 */
    private static String newPaperId32() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    private static String normalizePaperIdForDb(String raw) {
        if (!StringUtils.hasText(raw)) {
            return newPaperId32();
        }
        String t = raw.trim();
        if (t.length() <= 32) {
            return t;
        }
        return DigestUtils.md5DigestAsHex(t.getBytes(StandardCharsets.UTF_8));
    }

    /** question_id varchar(32) NOT NULL，空值用 DDL 默认占位。 */
    private static String normalizeQuestionIdForDb(String raw) {
        if (!StringUtils.hasText(raw)) {
            return "0";
        }
        String t = raw.trim();
        if (t.length() <= 32) {
            return t;
        }
        return DigestUtils.md5DigestAsHex(t.getBytes(StandardCharsets.UTF_8));
    }

    private static String normalizeTeacherIdForDb(String teacherId) {
        if (!StringUtils.hasText(teacherId)) {
            return "0";
        }
        String t = teacherId.trim();
        return t.length() <= 32 ? t : DigestUtils.md5DigestAsHex(t.getBytes(StandardCharsets.UTF_8));
    }

    /** wrong_word varchar(64) */
    private static String truncateWrongWordForDb(String raw) {
        if (raw == null) {
            return "";
        }
        String t = raw.trim();
        if (t.length() <= 64) {
            return t;
        }
        return t.substring(0, 64);
    }

    private static List<String> normalizeWordList(List<String> words) {
        if (words == null) {
            return List.of();
        }
        return words.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }

    private static int[] allocateQuestionCountsByErrorRates(List<String> wordIds, List<String> wordErrorRates, int total) {
        int n = wordIds.size();
        int[] counts = new int[n];
        if (n == 0 || total <= 0) {
            return counts;
        }
        if (n == 1) {
            counts[0] = total;
            return counts;
        }
        boolean useRates = wordErrorRates != null && wordErrorRates.size() == n;
        double[] weights = new double[n];
        double sum = 0.0;
        if (useRates) {
            List<String> ensuredRates = Objects.requireNonNull(wordErrorRates);
            for (int i = 0; i < n; i++) {
                double w = parseErrorRateWeight(ensuredRates.get(i));
                weights[i] = Math.max(w, 0.01);
                sum += weights[i];
            }
        } else {
            for (int i = 0; i < n; i++) {
                weights[i] = 1.0;
                sum += 1.0;
            }
        }
        double[] exact = new double[n];
        for (int i = 0; i < n; i++) {
            exact[i] = total * weights[i] / sum;
        }
        int assigned = 0;
        for (int i = 0; i < n; i++) {
            counts[i] = (int) Math.floor(exact[i]);
            assigned += counts[i];
        }
        int remainder = total - assigned;
        Integer[] order = IntStream.range(0, n).boxed().toArray(Integer[]::new);
        Arrays.sort(order, Comparator.comparingDouble((Integer i) -> exact[i] - counts[i]).reversed());
        for (int k = 0; k < remainder; k++) {
            counts[order[k]]++;
        }
        return counts;
    }

    private static double parseErrorRateWeight(String s) {
        if (s == null || s.isBlank()) {
            return 1.0;
        }
        String t = s.trim();
        if (t.endsWith("%")) {
            t = t.substring(0, t.length() - 1).trim();
        }
        try {
            double v = Double.parseDouble(t);
            if (Double.isNaN(v) || v < 0) {
                return 1.0;
            }
            if (v <= 1.0) {
                return Math.max(v, 0.01);
            }
            return Math.max(v / 100.0, 0.01);
        } catch (NumberFormatException e) {
            return 1.0;
        }
    }

    private static List<String> resolveLibraryQuestionTypes(List<String> questionTypes) {
        if (questionTypes == null || questionTypes.isEmpty()) {
            return SUPPORTED_LIBRARY_QUESTION_TYPES;
        }
        List<String> filtered = questionTypes.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .filter(SUPPORTED_LIBRARY_QUESTION_TYPES::contains)
                .distinct()
                .toList();
        return filtered.isEmpty() ? SUPPORTED_LIBRARY_QUESTION_TYPES : filtered;
    }
}
