package com.txai.edu.teacher.assistant.dto;

import lombok.Data;

import java.util.List;

/**
 * 教师和管理的班级信息
 * @author zhoucong
 */
@Data
public class TeacherClassDTO {
    private String teacherId;
    private List<ClassInfoDTO> classInfos;

    @Data
    public static class ClassInfoDTO {
        private String classId;
        private String className;
    }
}
