package com.txai.edu.teacher.assistant.mcp;

import com.alibaba.fastjson2.JSON;
import com.txai.edu.teacher.assistant.config.McpResilienceProperties;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.tool.Result;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.retry.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * @author zhoucong
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaperPracticeResultMcpClient {

    private final WebClient practiceMcpWebClient;
    private final PaperPracticeMcpProperties paperPracticeMcpProperties;
    private final McpResilienceProperties mcpResilienceProperties;
    private final CircuitBreaker practiceMcpCircuitBreaker;
    private final Retry practiceMcpRetry;


    /**
     * 通用 MCP 调用（HTTP POST）。
     * @param systemType 外部系统类型
     * @param apiPath 接口路径
     * @param teacherId
     * @param classIds
     * @param startTime
     * @param endTime
     * @return
     */
    public Result<String> callExternalSystem(String systemType, String apiPath, String teacherId, List<String> classIds, Long startTime, Long endTime) {
        String op = systemType + ":" + apiPath;


        if (!paperPracticeMcpProperties.getAllowlist().contains(op)) {
            log.warn("MCP请求被拒绝，未在白名单内，op={}", op);
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_FORBIDDEN.getCode());
            return Result.fail(EduTeacherEnum.MCP_FORBIDDEN);
        }

        if (!StringUtils.hasText(paperPracticeMcpProperties.getAuthToken())) {
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_UNAUTHORIZED.getCode());
            return Result.fail(EduTeacherEnum.MCP_UNAUTHORIZED);
        }

        Supplier<String> perAttempt = CircuitBreaker.decorateSupplier(
                practiceMcpCircuitBreaker,
                () -> paperPracticeMcpProperties.isMockTransportEnabled()
                        ? mockRemoteCall(systemType, apiPath, teacherId, classIds, startTime, endTime)
                        : doHttpCall(systemType, apiPath, teacherId, classIds, startTime, endTime));

        Supplier<String> withRetry = Retry.decorateSupplier(practiceMcpRetry, perAttempt);

        Instant start = Instant.now();
        try {
            String payload = withRetry.get();
            long elapsedMs = Duration.between(start, Instant.now()).toMillis();
            log.info("MCP调用成功，systemType={} apiPath={} elapsedMs={}", systemType, apiPath, elapsedMs);
            return Result.ok(payload);
        } catch (CallNotPermittedException e) {
            log.warn("MCP熔断拒绝调用，systemType={} apiPath={}", systemType, apiPath);
            return fallbackOrFail(systemType, apiPath, teacherId, classIds, startTime, endTime,  EduTeacherEnum.MCP_CIRCUIT_OPEN.getCode(), "circuit breaker open");
        } catch (Exception e) {
            log.warn("MCP调用失败，systemType={} apiPath={} err={}", systemType, apiPath, e.toString());
            return fallbackOrFail(systemType, apiPath, teacherId, classIds, startTime, endTime, EduTeacherEnum.MCP_UNAVAILABLE.getCode(), "external system unavailable");
        }
    }

    public Result<String> callExternalSystem(String systemType, String apiPath, List<String> practiceIds, String errorRate) {
        String op = systemType + ":" + apiPath;

        if (!paperPracticeMcpProperties.getAllowlist().contains(op)) {
            log.warn("MCP请求被拒绝，未在白名单内，op={}", op);
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_FORBIDDEN.getCode());
            return Result.fail(EduTeacherEnum.MCP_FORBIDDEN);
        }

        if (!StringUtils.hasText(paperPracticeMcpProperties.getAuthToken())) {
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_UNAUTHORIZED.getCode());
            return Result.fail(EduTeacherEnum.MCP_UNAUTHORIZED);
        }

        Supplier<String> perAttempt = CircuitBreaker.decorateSupplier(
                practiceMcpCircuitBreaker,
                () -> paperPracticeMcpProperties.isMockTransportEnabled()
                        ? mockRemoteCall(systemType, apiPath, practiceIds, errorRate)
                        : doHttpCall(systemType, apiPath, practiceIds, errorRate));

        Supplier<String> withRetry = Retry.decorateSupplier(practiceMcpRetry, perAttempt);

        Instant start = Instant.now();
        try {
            String payload = withRetry.get();
            long elapsedMs = Duration.between(start, Instant.now()).toMillis();
            log.info("MCP调用成功，systemType={} apiPath={} elapsedMs={}", systemType, apiPath, elapsedMs);
            return Result.ok(payload);
        } catch (CallNotPermittedException e) {
            log.warn("MCP熔断拒绝调用，systemType={} apiPath={}", systemType, apiPath);
            return fallbackOrFail(systemType, apiPath, practiceIds, errorRate, EduTeacherEnum.MCP_CIRCUIT_OPEN.getCode(), "circuit breaker open");
        } catch (Exception e) {
            log.warn("MCP调用失败，systemType={} apiPath={} err={}", systemType, apiPath, e.toString());
            return fallbackOrFail(systemType, apiPath, practiceIds, errorRate, EduTeacherEnum.MCP_UNAVAILABLE.getCode(), "external system unavailable");
        }
    }

    public Result<String> callExternalSystem(String systemType, String apiPath, Map<String, Object> payload) {
        String op = systemType + ":" + apiPath;

        if (!paperPracticeMcpProperties.getAllowlist().contains(op)) {
            log.warn("MCP请求被拒绝，未在白名单内，op={}", op);
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_FORBIDDEN.getCode());
            return Result.fail(EduTeacherEnum.MCP_FORBIDDEN);
        }

        if (!StringUtils.hasText(paperPracticeMcpProperties.getAuthToken())) {
            countFailure(systemType, apiPath, EduTeacherEnum.MCP_UNAUTHORIZED.getCode());
            return Result.fail(EduTeacherEnum.MCP_UNAUTHORIZED);
        }

        Supplier<String> perAttempt = CircuitBreaker.decorateSupplier(
                practiceMcpCircuitBreaker,
                () -> paperPracticeMcpProperties.isMockTransportEnabled()
                        ? mockRemoteCall(systemType, apiPath, payload)
                        : doHttpCall(systemType, apiPath, payload));

        Supplier<String> withRetry = Retry.decorateSupplier(practiceMcpRetry, perAttempt);

        Instant start = Instant.now();
        try {
            String resultPayload = withRetry.get();
            long elapsedMs = Duration.between(start, Instant.now()).toMillis();
            log.info("MCP调用成功，systemType={} apiPath={} elapsedMs={}", systemType, apiPath, elapsedMs);
            return Result.ok(resultPayload);
        } catch (CallNotPermittedException e) {
            log.warn("MCP熔断拒绝调用，systemType={} apiPath={}", systemType, apiPath);
            return fallbackOrFail(systemType, apiPath, payload, EduTeacherEnum.MCP_CIRCUIT_OPEN.getCode(), "circuit breaker open");
        } catch (Exception e) {
            log.warn("MCP调用失败，systemType={} apiPath={} err={}", systemType, apiPath, e.toString());
            return fallbackOrFail(systemType, apiPath, payload, EduTeacherEnum.MCP_UNAVAILABLE.getCode(), "external system unavailable");
        }
    }

    /**
     * WebClient 的 {@code bodyValue} 只能发<strong>一个</strong>请求体对象。多个业务字段应合并为 JSON（或表单等）一次发送。
     * 若对端要求 {@code text/plain}，可自行改为 {@code JSON.toJSONString(body)} 仍用 {@link MediaType#TEXT_PLAIN}，
     * 或与对端约定为 {@code application/x-www-form-urlencoded} 使用 {@code BodyInserters#fromFormData}。
     */
    private String doHttpCall(String systemType, String apiPath, String teacherId, List<String> classIds, Long startTime, Long endTime) {
        String baseUrl = switch (systemType) {
            case "paper" -> paperPracticeMcpProperties.getPracticeUrl();
            default -> throw new IllegalArgumentException("unsupported systemType");
        };
        String url = baseUrl + apiPath;
        String traceId = UUID.randomUUID().toString();
        long blockTimeoutMs = Math.max(3000L, mcpResilienceProperties.getTimeoutMs() + 2000L);
        String jsonBody = buildRequestJson(teacherId, classIds, startTime, endTime);
        return practiceMcpWebClient.post()
                .uri(url)
                .header("Authorization", "Bearer " + paperPracticeMcpProperties.getAuthToken())
                .header("X-Trace-Id", traceId)
                .contentType(Objects.requireNonNull(MediaType.APPLICATION_JSON))
                .bodyValue(Objects.requireNonNull(jsonBody))
                .retrieve()
                .onStatus(HttpStatusCode::isError, response -> response.createException().flatMap(Mono::error))
                .bodyToMono(String.class)
                .block(Duration.ofMillis(blockTimeoutMs));
    }

    private String doHttpCall(String systemType, String apiPath, List<String> practiceIds, String errorRate) {
        String baseUrl = switch (systemType) {
            case "paper" -> paperPracticeMcpProperties.getPracticeUrl();
            default -> throw new IllegalArgumentException("unsupported systemType");
        };
        String url = baseUrl + apiPath;
        String traceId = UUID.randomUUID().toString();
        long blockTimeoutMs = Math.max(3000L, mcpResilienceProperties.getTimeoutMs() + 2000L);
        String jsonBody = buildRequestJson(practiceIds, errorRate);
        return practiceMcpWebClient.post()
                .uri(url)
                .header("Authorization", "Bearer " + paperPracticeMcpProperties.getAuthToken())
                .header("X-Trace-Id", traceId)
                .contentType(Objects.requireNonNull(MediaType.APPLICATION_JSON))
                .bodyValue(Objects.requireNonNull(jsonBody))
                .retrieve()
                .onStatus(HttpStatusCode::isError, response -> response.createException().flatMap(Mono::error))
                .bodyToMono(String.class)
                .block(Duration.ofMillis(blockTimeoutMs));
    }

    private String doHttpCall(String systemType, String apiPath, Map<String, Object> payload) {
        String baseUrl = switch (systemType) {
            case "paper" -> paperPracticeMcpProperties.getPracticeUrl();
            default -> throw new IllegalArgumentException("unsupported systemType");
        };
        String url = baseUrl + apiPath;
        String traceId = UUID.randomUUID().toString();
        long blockTimeoutMs = Math.max(3000L, mcpResilienceProperties.getTimeoutMs() + 2000L);
        String jsonBody = JSON.toJSONString(payload == null ? Map.of() : payload);
        return practiceMcpWebClient.post()
                .uri(url)
                .header("Authorization", "Bearer " + paperPracticeMcpProperties.getAuthToken())
                .header("X-Trace-Id", traceId)
                .contentType(Objects.requireNonNull(MediaType.APPLICATION_JSON))
                .bodyValue(Objects.requireNonNull(jsonBody))
                .retrieve()
                .onStatus(HttpStatusCode::isError, response -> response.createException().flatMap(Mono::error))
                .bodyToMono(String.class)
                .block(Duration.ofMillis(blockTimeoutMs));
    }

    /** 与对端 DTO 字段名对齐即可；此处为通用 JSON 一坨。 */
    private static String buildRequestJson(String teacherId, List<String> classIds, Long startTime, Long endTime) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("teacherId", teacherId);
        body.put("classIds", classIds == null ? List.of() : classIds);
        body.put("startTime", startTime);
        body.put("endTime", endTime);
        return JSON.toJSONString(body);
    }

    private static String buildRequestJson(List<String> practiceIds, String errorRate) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("practiceIds", practiceIds == null ? List.of() : practiceIds);
        body.put("errorRate", errorRate);
        return JSON.toJSONString(body);
    }

    private void countFailure(String systemType, String apiPath, Integer code) {
        log.warn("MCP调用统计，result=failure。 systemType={} apiPath={} code={}", systemType, apiPath, code);
    }

    /**
     * 模拟远程调用。  班级&错词练习
     */
    private String mockRemoteCall(String systemType, String apiPath, String teacherId, List<String> classIds, Long startTime, Long endTime) {
        if ("paper".equals(systemType) && "/class/practice/error".equals(apiPath)) {

            return switch (teacherId) {
                case "zhoucong" -> """
                        {"errorWordPractices":[{"classId":"C001","className":"一年级1班","practiceId":"P001","practiceName":"英语基础练习1","startTime":1742112000000,"endTime":1742198400000},{"classId":"C002","className":"高二年级2班","practiceId":"P002","practiceName":"数学口算练习","startTime":1742112000000,"endTime":1742198400000},{"classId":"C003","className":"高二年级3班","practiceId":"P003","practiceName":"英语单词错词练习11111","startTime":1742112000000,"endTime":1742198400000}]}
                        """;
                case "liuxianpeng" -> """
                        {"errorWordPractices":[{"classId":"C005","className":"高三年级1班","practiceId":"P101","practiceName":"英语基础练习5","startTime":1742112000000,"endTime":1742198400000},{"classId":"C006","className":"高三年级2班","practiceId":"P102","practiceName":"英语听力练习","startTime":1742112000000,"endTime":1742198400000}]}
                        """;
                default -> """
                       {"errorWordPractices":[{"classId":"%s","className":"高三年级1班","practiceId":"P101","practiceName":"英语基础练习5","startTime":1742112000000,"endTime":1742198400000}]}
                        """.formatted(teacherId);
            };
        }

        throw new IllegalArgumentException("unsupported operation");
    }

    private String mockRemoteCall(String systemType, String apiPath, List<String> practiceIds, String errorRate) {
        if ("paper".equals(systemType) && "/practice/error/word".equals(apiPath)) {
            String key = normalizeMockErrorRateKey(errorRate);
            if ("100".equals(key)) {
                return """
                        [{"errorWords":[{"errorRate":"100","wordId":"W001","wordContent":"because"}]}]
                        """;
            }
            // 空串、未传、50、50% 或其它未单独建模的筛选：mock 统一走「约 50% 档位」数据集
            return """
                    [{"errorWords":[{"errorRate":"88","wordId":"W001","wordContent":"length"},{"errorRate":"63","wordId":"W002","wordContent":"hello"},{"errorRate":"58","wordId":"W004","wordContent":"world"}]}]
                    """;
        }
        throw new IllegalArgumentException("unsupported operation");
    }

    private String mockRemoteCall(String systemType, String apiPath, Map<String, Object> payload) {
        if ("paper".equals(systemType) && "/paper/review/replace".equals(apiPath)) {
            String paperId = "paper-mock-replace";
            int oldQuestionNo = 1;
            String wrongWord = "obvious";
            if (payload != null) {
                if (payload.get("paperId") != null && StringUtils.hasText(String.valueOf(payload.get("paperId")))) {
                    paperId = String.valueOf(payload.get("paperId")).trim();
                }
                if (payload.get("questionNo") != null) {
                    Object qn = payload.get("questionNo");
                    if (qn instanceof Number num) {
                        oldQuestionNo = num.intValue();
                    } else {
                        try {
                            oldQuestionNo = Integer.parseInt(String.valueOf(qn).trim());
                        } catch (NumberFormatException ignored) {
                            oldQuestionNo = 1;
                        }
                    }
                }
                if (payload.get("wrongWord") != null && StringUtils.hasText(String.valueOf(payload.get("wrongWord")))) {
                    wrongWord = String.valueOf(payload.get("wrongWord")).trim();
                }
            }
            Map<String, Object> one = new LinkedHashMap<>();
            one.put("paperId", paperId);
            one.put("questionNo", oldQuestionNo);
            one.put("questionId", "Q-REP-MOCK-9001");
            one.put("wrongWord", wrongWord);
            one.put("questionContent", "The solution is ______ to anyone who has read the notes.");
            one.put("answerAnalysis", "-");
            one.put("difficultyStar", 5);
            one.put("extension", "(Replace) ");
            Map<String, Object> root = new LinkedHashMap<>();
            root.put("errorWordPapers", List.of(one));
            return JSON.toJSONString(root);
        } else if ("paper".equals(systemType) && "/paper/review/library".equals(apiPath)) {
            return """
                    {
                      
                      "errorWordPapers":[
                        {
                          "paperId":"paper22222222",
                          "questionNo":11,
                          "questionId":"Q-LIB-1001",
                          "wrongWord":"where",
                          "questionContent":"______ (无论何处) you go, you'll always find people who share your interests. ",
                          "answerAnalysis":"",
                          "difficultyStar":2
                        },
                        {
                          "paperId":"paper22222222",
                          "questionNo":12,
                          "questionId":"Q-LIB-1002",
                          "wrongWord":"full",
                          "questionContent":"For a ______(首字母为f) understanding of the topic, please read the entire chapter.",
                          "answerAnalysis":"full",
                          "difficultyStar":3
                        }
                      ]
                    }
                    """;
        } else if ("paper".equals(systemType) && "/paper/review/error".equals(apiPath)) {
            return """
                    {
                      
                      "errorWordPapers":[
                        {
                          "paperId":"paper000001",
                          "questionNo":1,
                          "questionId":"Q-ERR-1001",
                          "wrongWord":"obvious",
                          "questionContent":"The answer is ______ to everyone after reading the chart.",
                          "answerAnalysis":"考查形容词 obvious 的语义搭配与语境判断。",
                          "difficultyStar":2
                        },
                        {
                          "paperId":"paper000001",
                          "questionNo":2,
                          "questionId":"Q-ERR-1002",
                          "wrongWord":"length",
                          "questionContent":"Please keep your speech within the required ______.",
                          "answerAnalysis":"考查名词 length 在固定语境中的正确使用。",
                          "difficultyStar":3
                        }
                      ]
                    }
                    """;
        }
        throw new IllegalArgumentException("unsupported operation");
    }

    /** mock：未传或空白错误率时按 50% 档位返回；支持 "50"、"50%" 等写法。 */
    private static String normalizeMockErrorRateKey(String errorRate) {
        if (!StringUtils.hasText(errorRate)) {
            return "50";
        }
        String t = errorRate.trim();
        if (t.endsWith("%")) {
            t = t.substring(0, t.length() - 1).trim();
        }
        return StringUtils.hasText(t) ? t : "50";
    }

    private Result<String> fallbackOrFail(String systemType, String apiPath, String teacherId, List<String> classIds, Long startTime, Long endTime, Integer code, String message) {
        countFailure(systemType, apiPath, code);
        if (!paperPracticeMcpProperties.isMockFallbackEnabled()) {
            return Result.fail(code, message);
        }
        try {
            String mock = mockRemoteCall(systemType, apiPath, teacherId, classIds, startTime, endTime);
            log.warn("MCP降级为mock返回，systemType={} apiPath={} code={}", systemType, apiPath, code);
            return Result.ok(mock);
        } catch (Exception e) {
            return Result.fail(code, message);
        }
    }

    private Result<String> fallbackOrFail(String systemType, String apiPath, List<String> practiceIds, String errorRate, Integer code, String message) {
        countFailure(systemType, apiPath, code);
        if (!paperPracticeMcpProperties.isMockFallbackEnabled()) {
            return Result.fail(code, message);
        }
        try {
            String mock = mockRemoteCall(systemType, apiPath, practiceIds, errorRate);
            log.warn("MCP降级为mock返回，systemType={} apiPath={} code={}", systemType, apiPath, code);
            return Result.ok(mock);
        } catch (Exception e) {
            return Result.fail(code, message);
        }
    }

    private Result<String> fallbackOrFail(String systemType, String apiPath, Map<String, Object> payload, Integer code, String message) {
        countFailure(systemType, apiPath, code);
        if (!paperPracticeMcpProperties.isMockFallbackEnabled()) {
            return Result.fail(code, message);
        }
        try {
            String mock = mockRemoteCall(systemType, apiPath, payload);
            log.warn("MCP降级为mock返回，systemType={} apiPath={} code={}", systemType, apiPath, code);
            return Result.ok(mock);
        } catch (Exception e) {
            return Result.fail(code, message);
        }
    }
}
