package com.txai.edu.teacher.assistant.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 登录会话配置（chatId -> teacherId）。
 */
@Data
@ConfigurationProperties(prefix = "teacher.session")
public class TeacherSessionProperties {
    private String keyPrefix = "edu:chat:session:";
    private int ttlMinutes = 120;
}
