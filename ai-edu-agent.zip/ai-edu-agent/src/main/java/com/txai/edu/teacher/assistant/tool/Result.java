package com.txai.edu.teacher.assistant.tool;

import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;

/**
 * @author zhoucong
 */
public record Result<T>(boolean success, Integer code, String message, T data) {

    public static <T> Result<T> ok(T data) {
        return new Result<>(true, EduTeacherEnum.SUCCESS.getCode(), EduTeacherEnum.SUCCESS.getMsg(), data);
    }

    public static <T> Result<T> fail(Integer code, String message) {
        return new Result<>(false, code, message, null);
    }

    public static <T> Result<T> fail(EduTeacherEnum teacherEnum) {
        return fail(teacherEnum.getCode(), teacherEnum.getMsg());
    }
}