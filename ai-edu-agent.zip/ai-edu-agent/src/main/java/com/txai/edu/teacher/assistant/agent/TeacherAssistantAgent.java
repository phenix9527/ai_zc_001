package com.txai.edu.teacher.assistant.agent;

import com.alibaba.fastjson2.JSON;
import com.txai.edu.teacher.assistant.config.AiModelProperties;
import com.txai.edu.teacher.assistant.service.TeacherAssistantAiService;
import dev.langchain4j.service.TokenStream;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 教师助手智能体
 *
 * @author zhoucong
 */
@Slf4j
@Component
@Validated
@RequiredArgsConstructor
public class TeacherAssistantAgent {

    @Value("classpath:prompts/teacher-assistant-system.txt")
    private Resource systemPromptResource;

    private final TeacherAssistantAiService teacherAssistantAiService;
    private final AiModelProperties aiModelProperties;

    public String handleRequest(@NotBlank(message = "teacherId 不能为空") String teacherId,
                                @NotBlank(message = "chatId 不能为空") String chatId,
                                @NotBlank(message = "message 不能为空") String userInput) {
        log.info("主Agent处理请求：teacherId={}, chatId={}, message={}", teacherId, chatId, userInput);
        String enrichedInput = buildEnrichedUserContent(teacherId, userInput);

        try {
            return teacherAssistantAiService.chat(chatId, enrichedInput);
        } catch (Exception e) {
            log.warn("主Agent调用大模型失败，降级到本地规则分发", e);
            if (userInput.contains("生成试卷") || userInput.contains("试卷预览") || userInput.contains("预览") || userInput.contains("生成") || userInput.contains("错词组卷")) {
            }
            return "无法理解需求，请输入组卷指令。规则：" + promptTitle();
        }
    }

    /**
     * LangChain4j {@link TokenStream} + SSE：工具调用与记忆与 {@link #handleRequest} 一致，增量推送模型文本。
     */
    public void handleRequestStream(@NotBlank String teacherId,
                                    @NotBlank String chatId,
                                    @NotBlank String userInput,
                                    SseEmitter emitter) {
        log.info("主Agent流式请求：teacherId={}, chatId={}, message={}", teacherId, chatId, userInput);
        String enrichedInput = buildEnrichedUserContent(teacherId, userInput);
        try {
            sendSseJson(emitter, "meta", Map.of("chatId", chatId));
        } catch (IOException e) {
            log.warn("SSE meta 发送失败", e);
            emitter.complete();
            return;
        }

        TokenStream stream;
        try {
            stream = teacherAssistantAiService.chatStream(chatId, enrichedInput);
        } catch (Exception e) {
            log.warn("创建 TokenStream 失败", e);
            try {
                sendSseJson(emitter, "error", Map.of("message", e.getMessage() != null ? e.getMessage() : "stream init failed"));
            } catch (IOException ignored) {
            }
            emitter.complete();
            return;
        }

        CountDownLatch streamFinished = new CountDownLatch(1);
        AtomicBoolean ended = new AtomicBoolean(false);
        Runnable signalStreamEnd = () -> {
            if (ended.compareAndSet(false, true)) {
                streamFinished.countDown();
            }
        };

        stream.onPartialResponse((String chunk) -> {
                    if (chunk == null || chunk.isEmpty()) {
                        return;
                    }
                    try {
                        sendSseJson(emitter, "delta", Map.of("text", chunk));
                    } catch (IOException e) {
                        log.debug("SSE delta 发送中断（可能客户端已断开）", e);
                    }
                })
                .onCompleteResponse(response -> {
                    try {
                        sendSseJson(emitter, "done", Map.of());
                    } catch (IOException ignored) {
                    }
                    emitter.complete();
                    signalStreamEnd.run();
                })
                .onError(error -> {
                    log.warn("流式生成失败", error);
                    try {
                        sendSseJson(emitter, "error", Map.of("message", error.getMessage() != null ? error.getMessage() : "stream error"));
                    } catch (IOException ignored) {
                    }
                    emitter.complete();
                    signalStreamEnd.run();
                })
                .start();

        long awaitMs = Math.max(120_000L, aiModelProperties.getTimeoutMs() + 60_000L);
        try {
            if (!streamFinished.await(awaitMs, TimeUnit.MILLISECONDS)) {
                log.warn("TokenStream 在 {}ms 内未结束，Langfuse 上下文可能不完整", awaitMs);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("等待流式结束被中断", e);
        }
    }

    private String buildEnrichedUserContent(String teacherId, String userInput) {
        String enrichedInput = "当前登录教师ID：" + teacherId + "\n用户问题：" + userInput;
        if (wantsQuestionLibraryPaperIntent(userInput)) {
            enrichedInput += """
                    【系统执行提示】用户已明确「新题/题库组卷」意图：本轮必须发起一次工具调用 **genPaperReviewQuestionLibrarySkill**（不可仅用 listWrongWordSortedByErrorRate 结束）。
                    参数建议：questionTypes 可传 []；totalCount 缺省 20；stageId 与 stageName 均使用最近一次 getTeacherInfo 返回中的 **stage** 字段字符串（若无则先 getTeacherInfo 再组卷）。
                    wordIds 与 wordErrorRates 与最近一次 listWrongWordSortedByErrorRate 返回的 errorWords 顺序一致；若尚无错词结果，本轮内先 listWrongWordSortedByErrorRate（practiceIds 来自上文）再立即 genPaperReviewQuestionLibrarySkill。
                    【呈现】工具返回中有几道题，回复里对用户展示的「新题组卷」类题目表就只能有几道；禁止为凑满 totalCount 或错词数而自行补题、扩表或在工具表外再造第二张题表；请原样使用工具返回中的 ### 新题组卷预览 Markdown 表。""";
        }
        return enrichedInput;
    }

    /**
     * 与 {@code teacher-assistant-system.txt}、{@code PaperReviewSkill} 中「题库组卷」工具说明一致。
     * 口语里常说「新题」即新题组卷；排除「新题型」等教学分析用语，避免误注入组卷指令。
     */
    static boolean wantsQuestionLibraryPaperIntent(String userInput) {
        if (userInput == null || userInput.isBlank()) {
            return false;
        }
        if (userInput.contains("新题型")) {
            return false;
        }
        return userInput.contains("题库组卷")
                || userInput.contains("新题组卷")
                || userInput.contains("新题");
    }

    private static void sendSseJson(SseEmitter emitter, String eventName, Map<String, Object> payload) throws IOException {
        String json = JSON.toJSONString(payload);
        emitter.send(SseEmitter.event().name(eventName).data(json, MediaType.APPLICATION_JSON));
    }

    /**
     * 从外置 prompt 里提取首行标题，作为兜底提示的一部分。
     */
    private String promptTitle() {
        try {
            String text = new String(systemPromptResource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            int idx = text.indexOf('\n');
            return idx > 0 ? text.substring(0, idx).trim() : text.trim();
        } catch (IOException e) {
            return "教师错词智能组卷 Agent";
        }
    }
}
