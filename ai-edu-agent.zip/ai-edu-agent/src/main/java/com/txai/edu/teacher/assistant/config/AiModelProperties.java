package com.txai.edu.teacher.assistant.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 唯一大模型入口配置。
 */
@Data
@ConfigurationProperties(prefix = "ai.model")
public class AiModelProperties {
    private String baseUrl = "https://api.deepseek.com";
    private String apiKey = "";
    private String modelName = "deepseek-chat";
    private Double temperature = 0.1;
    private Double topP = 0.9;
    private Integer timeoutMs = 120000;
}
