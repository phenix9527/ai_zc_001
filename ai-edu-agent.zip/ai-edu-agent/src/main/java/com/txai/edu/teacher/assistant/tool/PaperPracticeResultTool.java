package com.txai.edu.teacher.assistant.tool;

import com.txai.edu.teacher.assistant.dto.ClassPracticeDTO;
import com.txai.edu.teacher.assistant.dto.ErrorWordDTO;
import com.txai.edu.teacher.assistant.enums.EduTeacherEnum;
import com.txai.edu.teacher.assistant.mcp.PaperPracticeResultMcpAdapter;
import com.txai.edu.teacher.assistant.session.TeacherContextHolder;
import dev.langchain4j.agent.tool.Tool;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * @author zhoucong
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaperPracticeResultTool {

    private final PaperPracticeResultMcpAdapter paperPracticeResultMcpAdapter;

    @Tool(name = "listPracticeByTeacherAndClass", value = "根据教师、班级、时间段获取有错词的练习列表数据")
    public Result<ClassPracticeDTO> listPracticeByTeacherAndClass(String teacherId, List<String> classIds, Long startTime, Long endTime) {
        String contextTeacherId = TeacherContextHolder.getTeacherId();
        String resolvedTeacherId = StringUtils.hasText(contextTeacherId) ? contextTeacherId : teacherId;
        if (StringUtils.hasText(contextTeacherId) && StringUtils.hasText(teacherId) && !contextTeacherId.equals(teacherId)) {
            log.warn("Tool入参teacherId与会话teacherId不一致，优先使用会话值。arg={}, session={}", teacherId, contextTeacherId);
        }
        log.info("调用Tool：根据教师、班级、时间段获取有错词的练习列表数据. listPracticeByTeacherAndClass: {}, {}, {}, {}", resolvedTeacherId, classIds, startTime, endTime);
        Result<ClassPracticeDTO> result = paperPracticeResultMcpAdapter.listPracticeByTeacherAndClass(resolvedTeacherId, classIds, startTime, endTime);
        if (result.success()) {
            return result;
        }
        log.warn("用Tool：根据教师、班级、时间段获取有错词的练习列表数据失败，teacher={}, classIds={}, startTime={}, endTime={}, code={}", resolvedTeacherId, classIds, startTime, endTime, result.code());
        return Result.fail(EduTeacherEnum.GET_CLASS_ERROR_PRACTICE_INVALID);
    }


    @Tool(name = "listWrongWordSortedByErrorRate", value = "根据练习集合，错误率，错误率降序排序获取错词列表数据")
    public Result<List<ErrorWordDTO>> listWrongWordSortedByErrorRate(List<String> practiceIds, String errorRate) {
        log.info("调用Tool：listWrongWordSortedByErrorRate. listWrongWordSortedByErrorRate: practiceId={}, errorRate={}", practiceIds, errorRate);
        Result<List<ErrorWordDTO>> result = paperPracticeResultMcpAdapter.listWrongWordSortedByErrorRate(practiceIds, errorRate);
        if (result.success()) {
            return result;
        }
        log.warn("调用Tool：根据练习集合和错误率获取错词列表失败，practiceIds={}, errorRate={}, code={}", practiceIds, errorRate, result.code());
        return Result.fail(EduTeacherEnum.GET_PRACTICE_ERROR_WORD_INVALID);
    }

}
