package com.txai.edu.teacher.assistant.session;

import lombok.Builder;
import lombok.Data;

/**
 * 教师聊天会话上下文。
 */
@Data
@Builder
public class TeacherChatSession {
    private String chatId;
    private String teacherId;
    private String username;
    private long loginAt;
    private long lastActiveAt;
}
