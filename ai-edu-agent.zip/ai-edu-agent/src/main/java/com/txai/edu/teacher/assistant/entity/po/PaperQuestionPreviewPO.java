package com.txai.edu.teacher.assistant.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author zhoucong
 */
@Data
@TableName("paper_question_preview")
public class PaperQuestionPreviewPO {

    @TableId(type = IdType.AUTO)
    private Integer id;

    private String teacherId;

    private String paperId;

    /**
     * 1: 原题组卷; 2: 题库组卷; 3: 同词换题
     */
    private Integer genPaperType;

    private Integer questionNo;

    private String questionId;

    private String wrongWord;

    private String questionContent;

    private String answerAnalysis;

    private Integer difficultyStar;

    private String extension;

    private Integer isDeleted;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
