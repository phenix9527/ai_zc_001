package com.txai.edu.teacher.assistant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author zhoucong
 */

@Getter
@AllArgsConstructor
public enum EduTeacherEnum {

    SUCCESS(0, "成功"),

    GET_TEACHER_INFO_FAIL(100001, "获取教师信息失败"),
    GET_TEACHER_CLASS_INFO_FAIL(100002, "获取教师管理的班级列表信息失败"),
    CLASS_ID_ISNULL(100003, "班级数据为空"),
    DURATION_ISNULL(100004, "时间段为空"),
    TEACHER_CLASS_RELATION_INVALID(100005, "教师和班级关系无效"),
    GET_CLASS_ERROR_PRACTICE_INVALID(100006, "获取班级错词练习列表失败"),
    GET_PRACTICE_ERROR_WORD_INVALID(100007, "获取练习错词列表失败"),
    GEN_LIBRARY_PAPER_ERROR_WORD_ISNULL(100008, "请先提供错词 ID 列表后再进行题库组卷。"),
    REPLACE_SINGLE_QUESTION_PARAM_INVALID(100009, "同词换题失败：请提供有效的试卷 ID、题目序号 questionNo（与预览表序号列一致）与错词 wrongWord。"),





    // ----------------------   MCP  9000xx ------------------------------
    MCP_CIRCUIT_OPEN(900001, "MCP服务熔断打开"),
    MCP_FORBIDDEN(900002, "MCP服务为配置白名单，被禁止访问"),
    MCP_UNAUTHORIZED(900003, "MCP服务认证失败，未授权访问"),
    MCP_UNAVAILABLE(900004, "MCP服务不可用"),
    MCP_UNKNOWN(900005, "MCP服务未知异常"),


    ;

    private int code;
    private String msg;

}
