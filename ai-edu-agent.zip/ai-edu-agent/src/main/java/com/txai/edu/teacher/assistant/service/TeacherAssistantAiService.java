package com.txai.edu.teacher.assistant.service;

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.TokenStream;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.service.spring.AiService;
import dev.langchain4j.service.spring.AiServiceWiringMode;

/**
 * @author zhoucong
 */

@AiService(
        wiringMode = AiServiceWiringMode.EXPLICIT,
        chatModel = "chatModel",
        streamingChatModel = "streamingChatModel",
        chatMemoryProvider = "teacherChatMemoryProvider",
        tools = {"teacherTool", "paperPracticeResultTool", "paperReviewSkill"}
)
public interface TeacherAssistantAiService {

    @SystemMessage(fromResource = "prompts/teacher-assistant-system.txt")
    String chat(@MemoryId String chatId, @UserMessage String message);

    @SystemMessage(fromResource = "prompts/teacher-assistant-system.txt")
    TokenStream chatStream(@MemoryId String chatId, @UserMessage String message);
}
