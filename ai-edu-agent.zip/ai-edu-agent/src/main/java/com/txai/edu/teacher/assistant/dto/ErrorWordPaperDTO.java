package com.txai.edu.teacher.assistant.dto;

import lombok.Data;

import java.util.List;

/**
 * 原题组卷结果 DTO。
 */
@Data
public class ErrorWordPaperDTO {


    private List<ErrorWordPaper> errorWordPapers;

    @Data
    public static class ErrorWordPaper {
        /** 试卷ID */
        private String paperId;
        /** 题目序号 */
        private Integer questionNo;
        /** 题库中的题目ID */
        private String questionId;
        /** 对应错词 */
        private String wrongWord;
        /** 题目内容 */
        private String questionContent;
        /** 答案解析 */
        private String answerAnalysis;
        /** 题目难度星级（1-5） */
        private Integer difficultyStar;
    }
}
