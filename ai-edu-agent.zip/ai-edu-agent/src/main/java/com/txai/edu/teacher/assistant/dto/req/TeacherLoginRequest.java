package com.txai.edu.teacher.assistant.dto.req;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * @author zhoucong
 */
@Data
public class TeacherLoginRequest {

    @NotBlank(message = "username 不能为空")
    private String username;
    @NotBlank(message = "password 不能为空")
    private String password;
}
