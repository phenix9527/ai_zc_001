package com.txai.edu.teacher.assistant.dto.resp;

import lombok.Builder;
import lombok.Data;

/**
 * @author zhoucong
 */
@Data
@Builder
public class TeacherLoginResponse {
    private String chatId;
//    private String teacherId;
//    todo
}
