package com.txai.edu.teacher.assistant.config;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig.SlidingWindowType;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.core.IntervalFunction;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.http.codec.ClientCodecConfigurer;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

/**
 * WebClient + Resilience4j（熔断、重试）用于 {@link com.txai.edu.teacher.assistant.mcp.TeacherMcpClient}。
 * @author zhoucong
 */
@Configuration
public class TeacherMcpHttpConfiguration {

    public static final String TEACHER_MCP = "teacherMcp";

    @Bean
    public WebClient teacherMcpWebClient(WebClient.Builder webClientBuilder, McpResilienceProperties properties) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(Duration.ofMillis(Math.max(100, properties.getTimeoutMs())));
        return webClientBuilder
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .codecs(TeacherMcpHttpConfiguration::relaxCodecLimits)
                .build();
    }

    private static void relaxCodecLimits(ClientCodecConfigurer configurer) {
        configurer.defaultCodecs().maxInMemorySize(4 * 1024 * 1024);
    }

    @Bean
    public CircuitBreakerRegistry teacherMcpCircuitBreakerRegistry(McpResilienceProperties properties) {
        int threshold = Math.max(1, properties.getCircuitBreakerFailureThresholdCount());
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .slidingWindowType(SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(threshold)
                .minimumNumberOfCalls(threshold)
                .failureRateThreshold(100f)
                .waitDurationInOpenState(Duration.ofSeconds(Math.max(1, properties.getCircuitBreakerOpenSeconds())))
                .build();
        return CircuitBreakerRegistry.of(config);
    }

    @Bean
    public CircuitBreaker teacherMcpCircuitBreaker(CircuitBreakerRegistry teacherMcpCircuitBreakerRegistry) {
        return teacherMcpCircuitBreakerRegistry.circuitBreaker(TEACHER_MCP);
    }

    @Bean
    public RetryRegistry teacherMcpRetryRegistry(McpResilienceProperties properties) {
        int maxAttempts = Math.max(1, properties.getMaxRetries() + 1);
        RetryConfig config = RetryConfig.custom()
                .maxAttempts(maxAttempts)
                .ignoreExceptions(CallNotPermittedException.class)
                .intervalFunction(IntervalFunction.ofExponentialBackoff(
                        Duration.ofMillis(Math.max(1, properties.getRetryFirstDelayMs())),
                        properties.getRetryMultiplier(),
                        Duration.ofMillis(Math.max(1, properties.getRetryMaxDelayMs()))))
                .build();
        return RetryRegistry.of(config);
    }

    @Bean
    public Retry teacherMcpRetry(RetryRegistry teacherMcpRetryRegistry) {
        return teacherMcpRetryRegistry.retry(TEACHER_MCP);
    }
}
