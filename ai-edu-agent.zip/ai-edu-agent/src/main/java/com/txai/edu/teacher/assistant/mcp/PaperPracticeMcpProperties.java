package com.txai.edu.teacher.assistant.mcp;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Set;

/**
 * @author zhoucong
 */
@Data
@ConfigurationProperties(prefix = "practice.mcp")
public class PaperPracticeMcpProperties {
    private String practiceUrl = "http://up366-paper-practice:8081/api";
    private String authToken = "test-token";
    /**
     * 为 true 时不发起真实 HTTP，仅执行 {@code mockRemoteCall}；联调/上线真实 MCP 后改为 false。
     */
    private boolean mockTransportEnabled = true;
    private boolean mockFallbackEnabled = true;
    private Set<String> allowlist = Set.of(
            "paper:/class/practice/error",
            "paper:/practice/error/word",
            "paper:/paper/review/library",
            "paper:/paper/review/error",
            "paper:/paper/review/replace"
    );
}
