package com.txai.edu.teacher.assistant.memory;

import dev.langchain4j.memory.chat.ChatMemoryProvider;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * LangChain4j ChatMemory：按 chatId 分桶，底层 Redis 由 {@link RedisStringChatMemoryStore} 实现。
 */
@Configuration
public class TeacherChatMemoryConfig {

    @Bean
    ChatMemoryProvider teacherChatMemoryProvider(
            RedisStringChatMemoryStore redisStringChatMemoryStore,
            TeacherChatMemoryProperties properties) {
        return memoryId -> MessageWindowChatMemory.builder()
                .id(memoryId)
                .maxMessages(Math.max(4, properties.getMaxMessages()))
                .chatMemoryStore(redisStringChatMemoryStore)
                .build();
    }
}
