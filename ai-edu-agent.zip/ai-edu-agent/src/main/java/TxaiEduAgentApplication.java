import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.ComponentScan;
import org.mybatis.spring.annotation.MapperScan;

/**
 * 天学AI教育智能体项目入口
 *
 * @author zhoucong
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.txai.edu")
@ConfigurationPropertiesScan(basePackages = "com.txai.edu")
@MapperScan(basePackages = "com.txai.edu.teacher.assistant.mapper")
public class TxaiEduAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(TxaiEduAgentApplication.class, args);
    }
}
